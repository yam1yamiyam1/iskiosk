<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Illuminate\Http\Request;

class SalesCompleteController extends Controller
{
    public function __invoke(Request $request)
    {
        $Sales = Sale::query()
            ->where('sale_status', 'Pending')
            ->with('customer')
            ->latest()
            ->get();

        return view('sales.complete-sales', [
            'sales' => $sales
        ]);
    }
}
