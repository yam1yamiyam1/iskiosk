<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Dispose;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StaffController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $shopAssigned = $user->shop->name ?? null;
        $viewType = $request->view_type ?? 'sale';

        if ($shopAssigned) {

            $disposes = Dispose::with(['product.brand'])
                ->where('shop_id', $user->shop_id)
                ->where('dispose_status', 0)
                ->get()
                ->map(function ($dispose) {
                    $dispose->formatted_created_at = $dispose->created_at
                        ->copy()
                        ->timezone('Asia/Manila')
                        ->format('F j, Y g:i A');
                    return $dispose;
                });

            $totaldisposes = $disposes->count();

            if ($viewType === 'product') {
                $sales = Sale::with(['details.product.brand'])
                    ->where('user_id', Auth::id())
                    ->where('sale_status', 0)
                    ->whereHas('details', function ($q) {
                        $q->where('order_status', 1);
                    })
                    ->get();
    
                $productSummary = [];
    
                foreach ($sales as $sale) {
                    foreach ($sale->details as $detail) {
                        $productId = $detail->product_id;
                        if (!isset($productSummary[$productId])) {
                            $productSummary[$productId] = [
                                'product_name' => $detail->product->name ?? 'N/A',
                                'brand_name' => $detail->product->brand->name ?? 'N/A',
                                'product_image' => $detail->product->product_image ?? null,
                                'quantity' => 0,
                                'remquantity' => $detail->product->shops->firstWhere('id', $user->shop_id)?->pivot->quantity ?? 0,
                                'total' => 0,
                                'selling_price' => $detail->product->selling_price ?? 0,
                            ];
                        }
    
                        $productSummary[$productId]['quantity'] += $detail->quantity;
                        $productSummary[$productId]['total'] += $detail->total;
                    }
                }
    
                return view('staff.daily-report', [
                    'saleData' => collect($productSummary),
                    'totaldisposes' => $totaldisposes,
                    'disposes' => $disposes,
                    'shopassigned' => $shopAssigned,
                    'viewType' => $viewType,
                ]);
            }

            $sales = Sale::with(['details.product.brand'])
                ->where('sale_status', 0)
                ->where('user_id', Auth::id())
                ->whereHas('details', function ($q) {
                    $q->where('order_status', 1);
                })
                ->get();

            $saleData = $sales->flatMap(function ($sale) {
                $totalForSale = $sale->details->sum('total');
                return $sale->details->map(function ($detail) use ($sale, $totalForSale) {
                    return [
                        'order_id'        => $detail->id,
                        'sale_id'        => $sale->id,
                        'product_name'   => $detail->product->name ?? 'N/A',
                        'brand_name'     => $detail->product->brand->name ?? 'N/A',
                        'quantity'       => $detail->quantity,
                        'selling_price'  => '₱' . number_format($detail->product->selling_price, 2),
                        'product_image'  => $detail->product->product_image ?? null,
                        'total_price'    => '₱' . number_format($detail->total, 2),
                        'payment_method' => $detail->payment_status == 1 ? 'Cash' :
                            ($detail->payment_status == 2 ? 'Gcash' :
                            ($detail->payment_status == 3 ? 'Cash and Gcash' : 'Unknown')),
                        'subtotalprice'  => $detail->total,
                        'totalprice'     => $totalForSale,
                        'cash'           => $detail->cash,
                        'gcash'          => $detail->gcash,
                        'created_at' => $sale->created_at->copy()->timezone('Asia/Manila')->format('F j, Y g:i A'),
                    ];
                });
            })->sortByDesc('sale_id')->values();
                


            return view('staff.daily-report', [
                'saleData' => $saleData,
                'disposes' => $disposes,
                'totaldisposes' => $totaldisposes,
                'shopassigned' => $shopAssigned,
                'viewType' => $viewType,
            ]);
        }
        else {
            return view('staff.daily-report', [
                'saleData' => collect(),
                'disposes' => collect(),
                'totaldisposes' => 0,
                'shopassigned' => 'No shop assigned',
                'viewType' => $viewType,
            ]);            
        }
    }

    public function staff()
    {
        $brands = Brand::select('id', 'name', 'brand_image')
            ->limit(50)
            ->get();

        $brandData = $brands->map(function ($brand) {
            return [
                'id' => $brand->id,
                'name' => $brand->name,
                'brand_image' => $brand->brand_image,
            ];
        });

        return view('staff.index', [
            'brandData' => $brandData,
        ]);
    }

    public function showBrand($id)
    {
        $brandData = Brand::all();
        $selectedBrand = Brand::findOrFail($id);
        
        $products = Product::select('id', 'name', 'quantity', 'selling_price', 'product_image')
            ->where('brand_id', $id)
            ->get();
        
        $productData = $products->map(function ($product) {
            return [
                'id' => $product->id,
                'name' => $product->name,
                'quantity' => $product->quantity,
                'selling_price' => '₱' . number_format($product->selling_price, 2),
                'product_image' => $product->product_image,
            ];
        });

        return view('staff.products', compact('brandData', 'selectedBrand', 'productData'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        $userId = auth()->id();
        $productId = $request->product_id;
        $brandId = $request->brand_id;
        $quantity = $request->quantity;

        $sale = Sale::where('user_id', $userId)
            ->where('sale_status', 0)
            ->first();

        if (!$sale) {
            $sale = Sale::create([
                'user_id' => $userId,
                'product_id' => $productId,
                'brand_id' => $brandId,
                'sale_date' => now()->toDateString(),
                'sale_status' => 0,
            ]);
        }

        $product = \App\Models\Product::findOrFail($productId);
        $total = $product->price * $quantity;

        $saledetails = SaleDetail::where('sale_id', $sale->id)
            ->where('product_id', $product->id)
            ->where('order_status', 0)
            ->first();

        if ($saledetails) {
            $saledetails->quantity += $quantity;
            $saledetails->total = $product->price * $saledetails->quantity;
            $saledetails->save();
        }
        else {
            SaleDetail::create([
                'sale_id' => $sale->id,
                'product_id' => $productId,
                'quantity' => $quantity,
                'total' => $total,
                'order_status' => '0',
            ]);
        }

        return redirect()->back()->with('success', 'Product added to purchase.');
    }

    public function clearreport()
    {
        $userId = auth()->id();
        $shopId = auth()->user()->shop_id;

        $saleDetails = SaleDetail::where('order_status', 0)
            ->whereHas('sale', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->get();

        foreach ($saleDetails as $detail) {
            DB::table('product_shop')
                ->where('product_id', $detail->product_id)
                ->where('shop_id', $shopId)
                ->increment('quantity', $detail->quantity);
        }

        $saleIds = $saleDetails->pluck('sale_id')->unique();

        SaleDetail::whereIn('id', $saleDetails->pluck('id'))->delete();
        Sale::whereIn('id', $saleIds)->delete();

        return back()->with('success', 'Pending orders cleared.');
    }


    public function destroy(Request $request, $order_id)
    {
        $saleDetail = SaleDetail::with('sale')->findOrFail($order_id);

        if (!$saleDetail) {
            return redirect()->back()->with('error', 'Order detail not found.');
        }
        
        $userId = auth()->id();
        $shopId = auth()->user()->shop_id;
        $cash = 0;
        $gcash = 0;

        if (auth()->user()->roles[0]->role == 0) {
            if ($saleDetail->sale->sale_status != 0) {
                return redirect()->back()->with('error', 'You are not authorized to delete this sale.');
            }

            if ($saleDetail->sale->shop_id != $shopId) {
                return redirect()->back()->with('error', 'You are not authorized to delete this sale.');
            }

            if ($saleDetail->sale->user_id != $userId) {
                return redirect()->back()->with('error', 'You are not authorized to delete this sale.');
            }
        }
        
        $query = SaleDetail::where('sale_id', $saleDetail->sale_id)
            ->where('id', '!=', $saleDetail->id);
        $totalOrderPrice = $query->sum('total');

        if ($saleDetail->payment_status == '3' && $totalOrderPrice) {
            $paymentmethod = $request->input('paymentmethoddelete');
            
            if ($paymentmethod == '3') {
                $cash = $request->input('cashAmountdelete', 0);
                $gcash = $request->input('gcashAmountdelete', 0);

                if ($cash < 1) {
                    return redirect()->back()->with('error', "Cash amount must be at least (₱1).");
                }

                if ($gcash < 1) {
                    return redirect()->back()->with('error', "GCash amount must be at least (₱1).");
                }

                if (($cash + $gcash) != $totalOrderPrice) {
                    return redirect()->back()->with('error', "The sum of Cash and GCash must equal the total order price (₱{$totalOrderPrice}).");
                }
            }
        }

        $productId = $saleDetail->product_id;
        $quantity = $saleDetail->quantity;
    
        $sale = \App\Models\Sale::find($saleDetail->sale_id);
        $shopId = $sale->shop_id;
    
        DB::table('product_shop')
            ->where('product_id', $productId)
            ->where('shop_id', $shopId)
            ->increment('quantity', $quantity);

        $exists = DB::table('sale_details')
            ->where('sale_id', $saleDetail->sale_id)
            ->exists();

        if ($exists && $totalOrderPrice) {
            if ($saleDetail->payment_status == '3') {
                DB::table('sale_details')
                    ->where('sale_id', $saleDetail->sale_id)
                    ->update([
                        'payment_status' => $paymentmethod,
                        'cash' => $cash,
                        'gcash' => $gcash,
                    ]);
            }
            DB::table('sale_details')->where('id', $order_id)->delete();
        } else {
            
            DB::table('sale_details')->where('id', $order_id)->delete();
            DB::table('sales')->where('id', $saleDetail->sale_id)->delete();
        }
    
    
        return redirect()->back()->with('success', 'Purchase deleted successfully.');
    }

    

    public function update(Request $request, $id)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
            'paymentmethod' => 'required|integer|min:1',
        ]);

        $cash = 0;
        $gcash = 0;

        $userId = auth()->id();
        $shopId = auth()->user()->shop_id;
    
        $saleDetail = SaleDetail::with('sale')->findOrFail($id);

        if (!$saleDetail) {
            return redirect()->back()->with('error', 'Order detail not found.');
        }

        if (auth()->user()->roles[0]->role == 0) {
            if ($saleDetail->sale->sale_status != 0) {
                return redirect()->back()->with('error', 'You are not authorized to update this sale.');
            }

            if ($saleDetail->sale->shop_id != $shopId) {
                return redirect()->back()->with('error', 'You are not authorized to update this sale.');
            }
            
            if ($saleDetail->sale->user_id != $userId) {
                return redirect()->back()->with('error', 'You are not authorized to update this sale.');
            }
        }


        $product = DB::table('products')->where('id', $saleDetail->product_id)->first();
    
        if (!$product) {
            return redirect()->back()->with('error', 'Product not found.');
        }
    
        $sale = \App\Models\Sale::find($saleDetail->sale_id);
    
        if (!$sale) {
            return redirect()->back()->with('error', 'Sale not found.');
        }
    
        $shopId = $sale->shop_id;
    
        $oldQuantity = $saleDetail->quantity;
        $newQuantity = $request->input('quantity');
        $paymentmethod = $request->input('paymentmethod');
        $difference = $newQuantity - $oldQuantity;
    
        $available = DB::table('product_shop')
            ->where('product_id', $saleDetail->product_id)
            ->where('shop_id', $shopId)
            ->value('quantity');
    
        if ($newQuantity > $available) {
            return redirect()->back()->with('error', 'Not enough stock. Available: ' . $available);
        }

        $query = SaleDetail::where('sale_id', $saleDetail->sale_id)
            ->where('id', '!=', $saleDetail->id);

        $totalOrderPrice = $query->sum('total');
        $total = $product->selling_price * $newQuantity;
        
        $totalOrderPrice += $total;

        if ($paymentmethod == '3') {
            $cash = $request->input('cashAmount', 0);
            $gcash = $request->input('gcashAmount', 0);

            if ($cash < 1) {
                return redirect()->back()->with('error', "Cash amount must be at least (₱1).");
            }

            if ($gcash < 1) {
                return redirect()->back()->with('error', "GCash amount must be at least (₱1).");
            }

            if (($cash + $gcash) != $totalOrderPrice) {
                return redirect()->back()->with('error', "The sum of Cash and GCash must equal the total order price (₱{$totalOrderPrice}).");
            }
        }
    
    
        DB::table('sale_details')
            ->where('id', $id)
            ->update([
                'quantity' => $newQuantity,
                'total' => $total,
            ]);
            
        DB::table('sale_details')
            ->where('sale_id', $saleDetail->sale_id)
            ->update([
                'payment_status' => $paymentmethod,
                'cash' => $cash,
                'gcash' => $gcash,
            ]);
    
        DB::table('product_shop')
            ->where('product_id', $saleDetail->product_id)
            ->where('shop_id', $shopId)
            ->update([
                'quantity' => DB::raw('quantity - ' . $difference),
            ]);
    
        return redirect()->back()->with('success', 'Record updated successfully.');
    }


}
