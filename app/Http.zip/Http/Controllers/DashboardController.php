<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Brand;
use App\Models\Dispose;
use App\Models\Shop;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $range = $request->get('range', 'daily');
        $salesData = collect();
        $labels = collect();
    
        switch ($range) {
            case 'weekly':
                $startOfMonth = Carbon::now()->startOfMonth();
                $endOfMonth = Carbon::now()->endOfMonth();
                
                $weekStart = $startOfMonth->copy();
                $weekEnd = $weekStart->copy()->endOfWeek();
    
                while ($weekStart <= $endOfMonth) {
                    $totalPrice = Sale::where('sale_status', 1)
                        ->whereBetween('created_at', [$weekStart, $weekEnd])
                        ->with('details')
                        ->get()
                        ->sum(function ($sale) {
                            return $sale->details->sum('total');
                        });
    
                    $salesData->push($totalPrice);
                    $labels->push('Week ' . $weekStart->weekOfMonth);
    
                    $weekStart = $weekEnd->copy()->addDay();
                    $weekEnd = $weekStart->copy()->endOfWeek();
                }
                break;
    
            case 'monthly':
                $start = Carbon::now()->subMonths(5)->startOfMonth();
                for ($i = 0; $i < 6; $i++) {
                    $month = $start->copy()->addMonths($i);
                    $totalPrice = Sale::where('sale_status', 1)
                        ->whereYear('created_at', $month->year)
                        ->whereMonth('created_at', $month->month)
                        ->with('details')
                        ->get()
                        ->sum(function ($sale) {
                            return $sale->details->sum('total');
                        });
    
                    $salesData->push($totalPrice);
                    $labels->push($month->format('M Y'));
                }
                break;
    
            case 'yearly':
                $start = Carbon::now()->subYears(5)->startOfYear();
                for ($i = 0; $i < 6; $i++) {
                    $year = $start->copy()->addYears($i);
                    $totalPrice = Sale::where('sale_status', 1)
                        ->whereYear('created_at', $year->year)
                        ->with('details')
                        ->get()
                        ->sum(function ($sale) {
                            return $sale->details->sum('total');
                        });
    
                    $salesData->push($totalPrice);
                    $labels->push($year->format('Y'));
                }
                break;
    
            case 'daily':
                $start = Carbon::now()->startOfWeek()->setTimezone('Asia/Manila');
                for ($i = 0; $i < 7; $i++) {
                    $date = $start->copy()->addDays($i)->format('Y-m-d');
                    $totalPrice = Sale::where('sale_status', 1)
                        ->whereDate('created_at', $date)
                        ->with('details')
                        ->get()
                        ->sum(function ($sale) {
                            return $sale->details->sum('total');
                        });
            
                    $salesData->push($totalPrice);
                    $labels->push(Carbon::parse($date)->format('l'));
                }
                break;

        }
        
        $topProducts = SaleDetail::whereHas('sale', function ($query) {
                $query->where('sale_status', 1);
            })
            ->with('product')
            ->get()
            ->groupBy('product_id')
            ->map(function ($productDetails) {
                return [
                    'product' => $productDetails->first()->product,
                    'sales' => $productDetails->sum('quantity'),
                ];
            })
            ->sortByDesc('sales')
            ->take(5)
            ->values();
        
        $topProductsData = $topProducts->map(function ($item) {
            return [
                'name' => $item['product']?->name ?? 'Unknown Product',
                'sales' => $item['sales'],
            ];
        });
    
        $salesGraphData = [
            'sales' => $salesData,
            'dates' => $labels,
        ];
    
        $users = User::whereHas('roles', fn($q) => $q->where('role', 0))->count();
        $admins = User::whereHas('roles', fn($q) => $q->where('role', 1))->count();
        $brands = Brand::count();
        $shops = Shop::count();
        $products = Product::count();
        $pendingsales = Sale::where('sale_status', 0)
            ->whereHas('details', function ($query) {
                $query->where('order_status', 1);
            })
            ->count();

        $completedSales = Sale::where('sale_status', 1)->count();
    
        return view('admin.index', compact(
            'brands', 'shops', 'products',
            'pendingsales', 'completedSales',
            'users', 'admins', 'salesGraphData', 'range', 'topProductsData'
        ));
    }



    public function staff()
    {
        
        $user = auth()->user();
        $shopAssigned = $user->shop->name ?? null;
        $totalPrice = 0;
        if ($shopAssigned) {
            $orders = SaleDetail::with('product')
                ->where('order_status', 0)
                ->whereHas('sale', function ($query) {
                    $query->where('user_id', auth()->user()->id);
                })
                ->get();

            $orderData = $orders->map(function ($order) {
                return [
                    'name' => $order->product->name,
                    'quantity' => $order->quantity,
                    'selling_price' => '₱' . number_format($order->product->selling_price, 2),
                    'total_price' => $order->total,
                ];
            });

            $brands = Brand::select('id', 'name', 'brand_image')
                ->get();

            $brandData = $brands->map(function ($brand) {
                return [
                    'id' => $brand->id,
                    'name' => $brand->name,
                    'brand_image' => $brand->brand_image,
                ];
            });

            $totalPrice = $orderData->sum('total_price');

            return view('staff.index', [
                'brandData' => $brandData,
                'orderData' => $orderData,
                'shopassigned' => $shopAssigned,
                'totalOrderPrice' => '₱' . number_format($totalPrice, 2),
            ]);
        }
        else {
            return view('staff.index', [
                'brandData' => collect(),
                'orderData' => collect(),
                'shopassigned' => 'No shop assigned',
                'totalOrderPrice' => '₱ 0.00',
            ]);            
        }
    }


    public function showBrand($id)
    {
        $user = auth()->user();
        $shopAssigned = $user->shop->name ?? null;
        $totalPrice = 0;
        if ($shopAssigned) {
            $orders = SaleDetail::with('product')
                ->where('order_status', 0)
                ->whereHas('sale', function ($query) {
                    $query->where('user_id', auth()->user()->id);
                })
                ->get();

            $orderData = $orders->map(function ($order) {
                return [
                    'name' => $order->product->name,
                    'quantity' => $order->quantity,
                    'selling_price' => '₱' . number_format($order->product->selling_price, 2),
                    'total_price' => $order->total,
                ];
            });

            $totalPrice = $orderData->sum('total_price');

            $brandData = Brand::all();
            $selectedBrand = Brand::findOrFail($id);

            $products = Product::with('shops')
                ->select('id', 'name', 'selling_price', 'product_image')
                ->where('brand_id', $id)
                ->get();

            $shopId = auth()->user()->shop_id ?? 0;

            $productData = $products->map(function ($product) use ($shopId) {
                $quantity = $product->shops->firstWhere('id', $shopId)?->pivot->quantity ?? 0;

                return [
                    'id' => $product->id,
                    'name' => $product->name,
                    'quantity' => $quantity,
                    'selling_price' => '₱' . number_format($product->selling_price, 2),
                    'product_image' => $product->product_image,
                ];
            });

            return view('staff.products', [
                'brandData' => $brandData,
                'selectedBrand' => $selectedBrand,
                'productData' => $productData,
                'orderData' => $orderData,
                'shopassigned' => $shopAssigned,
                'totalOrderPrice' => '₱' . number_format($totalPrice, 2),
            ]);
        }
        else {
            return view('staff.index', [
                'brandData' => collect(),
                'orderData' => collect(),
                'shopassigned' => 'No shop assigned',
                'totalOrderPrice' => '₱ 0.00',
            ]);            
        }
    }



    public function store(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        $userId = auth()->id();
        $productId = $request->product_id;
        $brandId = $request->brand_id;
        $quantity = $request->quantity;
        $shopId = auth()->user()->shop_id;

        $product = \App\Models\Product::findOrFail($productId);

        $available = DB::table('product_shop')
            ->where('product_id', $productId)
            ->where('shop_id', $shopId)
            ->value('quantity');

        if ($quantity > $available) {
            return redirect()->back()->with('error', 'Not enough stock. Available: ' . $available);
        }

        $sale = Sale::where('user_id', $userId)
            ->where('sale_status', 0)
            ->whereHas('details', function ($q) {
                $q->where('order_status', 0);
            })
            ->first();

        if (!$sale) {
            $sale = Sale::create([
                'user_id' => $userId,
                'product_id' => $productId,
                'brand_id' => $brandId,
                'shop_id' => $shopId,
                'sale_date' => now()->toDateString(),
                'sale_status' => 0,
            ]);
        }

        $total = $product->selling_price * $quantity;

        $saledetails = SaleDetail::where('sale_id', $sale->id)
            ->where('product_id', $product->id)
            ->where('order_status', 0)
            ->first();

        if ($saledetails) {
            $saledetails->quantity += $quantity;
            $saledetails->total = $product->selling_price * $saledetails->quantity;
            $saledetails->save();
        }
        else {
            SaleDetail::create([
                'sale_id' => $sale->id,
                'product_id' => $productId,
                'quantity' => $quantity,
                'total' => $total,
                'order_status' => 0,
            ]);
        }

        

        $product->shops()->updateExistingPivot($shopId, [
            'quantity' => DB::raw('quantity - ' . $quantity)
        ]);

        return redirect()->back()->with('success', 'Product added to purchase.');
    }


    public function storedispose(Request $request)
    {
        $request->validate([
            'product_id_dispose' => 'required|exists:products,id',
        ]);

        $userId = auth()->id();
        $productId = $request->product_id_dispose;
        $shopId = auth()->user()->shop_id;

        $product = \App\Models\Product::findOrFail($productId);

        $available = DB::table('product_shop')
            ->where('product_id', $productId)
            ->where('shop_id', $shopId)
            ->value('quantity');

        if ($available < 1) {
            return redirect()->back()->with('error', 'No stock available to dispose.');
        }

        $sale = Dispose::create([
            'user_id' => $userId,
            'product_id' => $productId,
            'shop_id' => $shopId,
            'dispose_date' => now()->toDateString(),
            'dispose_status' => 0,
        ]);

        $product->shops()->updateExistingPivot($shopId, [
            'quantity' => DB::raw('quantity - 1')
        ]);

        return redirect()->back()->with('success', 'Product successfully disposed.');
    }

    public function destroydispose($id)
    {
        $dispose = Dispose::findOrFail($id);
        $product = \App\Models\Product::findOrFail($dispose->product_id);

        $shopId = $dispose->shop_id;

        $product->shops()->updateExistingPivot($shopId, [
            'quantity' => DB::raw('quantity + 1')
        ]);

        $dispose->delete();

        return redirect()->back()->with('success', 'Disposed item removed successfully.');
    }


    public function orderlist(Request $request)
    {
        $sales = Sale::with(['details.product'])
            ->where('sale_status', 1)
            ->orderBy('sale_date', 'desc')
            ->get();

        return view('staff.daily_report', [
            'sales' => $sales,
        ]);
    }

    public function savereport(Request $request)
    {
        $paymentMethod = $request->input('payment_method');

        $cash = 0;
        $gcash = 0;

        $query = SaleDetail::where('order_status', 0)
            ->whereHas('sale', function ($q) {
                $q->where('user_id', auth()->id());
            });

        $totalOrderPrice = $query->sum('total');

        if ($paymentMethod == '3') {
            $cash = $request->input('cashAmount', 0);
            $gcash = $request->input('gcashAmount', 0);

            if ($cash < 1) {
                return response()->json(['error' => "Cash amount must be at least (₱1)."], 400);
            }

            if ($gcash < 1) {
                return response()->json(['error' => 'GCash amount must be at least (₱1).'], 400);
            }

            if (($cash + $gcash) != $totalOrderPrice) {
                return response()->json([
                    'error' => "The sum of Cash and GCash must equal the total order price (₱{$totalOrderPrice})."
                ], 400);
            }
        }

        $query->update([
            'order_status' => 1,
            'payment_status' => $paymentMethod,
            'cash' => $cash,
            'gcash' => $gcash,
        ]);

        return response()->json(['success' => true]);
    }
}
