<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;
use App\Models\User;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $user = Auth::user();

        if ($user && !$user->isActive()) {
            Auth::logout();
            return back()->withErrors([
                'email' => 'Your account is disabled. Please contact support.',
            ]);
        }

        $request->session()->regenerate();

        if ($user->hasRole('1')) {
            return redirect()->route('dashboard');
        } elseif ($user->hasRole('0')) {
            return redirect('/home');
        }
        
        Auth::logout();
        return redirect()->route('login')->withErrors([
            'email' => 'Unauthorized access.',
        ]);
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
