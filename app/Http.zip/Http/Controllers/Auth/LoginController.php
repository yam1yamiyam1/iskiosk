<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'signin-email' => 'required|string|email',
            'signin-password' => 'required|string',
        ]);
    
        if (auth()->attempt(['email' => $request->input('signin-email'), 'password' => $request->input('signin-password')])) {
            $user = auth()->user();
    
            if ($user->isActive()) {
                auth()->logout();
                return back()->withErrors([
                    'signin-email' => 'Your account is disabled. Please contact support.',
                ]);
            }
            
            return $this->authenticated($request, $user);
        }
    
        return back()->withErrors([
            'signin-email' => 'The provided credentials do not match our records.',
        ]);
    }

    protected function authenticated(Request $request, $user)
    {
        if ($user->hasRole('1')) {
            return redirect()->route('dashboard');
        } elseif ($user->hasRole('0')) {
            return redirect('/home');
        }

        return redirect($this->redirectTo);
    }

    public function logout(Request $request)
    {
        auth()->logout();
        return redirect('/login');
    }
}
