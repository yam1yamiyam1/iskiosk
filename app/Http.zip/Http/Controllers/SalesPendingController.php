<?php

namespace App\Http\Controllers;

use App\Enums\SaleStatus;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Dispose;
use App\Models\Shop;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class SalesPendingController extends Controller
{
    public function index(Request $request)
    {
        $shopId = $request->shop_id ?? Shop::orderBy('name')->first()?->id ?? null;
        $viewType = $request->view_type ?? 'sale';

        $shops = Shop::select('id', 'name')->orderBy('name')->get();

        if (!$shopId) {
            return view('admin.pending', [
                'saleData' => collect(),
                'shops' => $shops,
                'selectedShop' => '',
                'totaldisposes' => 0,
                'disposes' => collect(),
                'viewType' => $viewType
            ]);
        }

        $disposes = Dispose::with(['product.brand'])
            ->where('shop_id', $shopId)
            ->where('dispose_status', 0)
            ->get()
            ->map(function ($dispose) {
                $dispose->formatted_created_at = $dispose->created_at
                    ->copy()
                    ->timezone('Asia/Manila')
                    ->format('F j, Y g:i A');
                return $dispose;
            });

        $totaldisposes = $disposes->count();

        if ($viewType === 'product') {
            $sales = Sale::with(['details.product.brand'])
                ->where('shop_id', $shopId)
                ->where('sale_status', 0)
                ->whereHas('details', function ($q) {
                    $q->where('order_status', 1);
                })
                ->get();

            $productSummary = [];

            foreach ($sales as $sale) {
                foreach ($sale->details as $detail) {
                    $productId = $detail->product_id;
                    if (!isset($productSummary[$productId])) {
                        $productSummary[$productId] = [
                            'product_name' => $detail->product->name ?? 'N/A',
                            'brand_name' => $detail->product->brand->name ?? 'N/A',
                            'product_image' => $detail->product->product_image ?? null,
                            'remquantity' => $detail->product->shops->firstWhere('id', $shopId)?->pivot->quantity ?? 0,
                            'quantity' => 0,
                            'total' => 0,
                            'selling_price' => $detail->product->selling_price ?? 0,
                        ];
                    }

                    $productSummary[$productId]['quantity'] += $detail->quantity;
                    $productSummary[$productId]['total'] += $detail->total;
                }
            }

            return view('admin.pending', [
                'saleData' => collect($productSummary),
                'shops' => $shops,
                'totaldisposes' => $totaldisposes,
                'disposes' => $disposes,
                'selectedShop' => $shopId,
                'viewType' => $viewType,
            ]);
        }

        $sales = Sale::with(['details.product.brand', 'user'])
            ->where('shop_id', $shopId)
            ->where('sale_status', 0)
            ->whereHas('details', function ($q) {
                $q->where('order_status', 1);
            })
            ->get();

        $saleData = $sales->flatMap(function ($sale) {
            $totalForSale = $sale->details->sum('total');
            $staffName = $sale->user ? $sale->user->fname . ' ' . $sale->user->lname : 'N/A';
            return $sale->details->map(function ($detail) use ($sale, $totalForSale, $staffName) {
                return [
                    'order_id' => $detail->id,
                    'sale_id' => $sale->id,
                    'staff_name'     => $staffName,
                    'product_name' => $detail->product->name ?? 'N/A',
                    'brand_name' => $detail->product->brand->name ?? 'N/A',
                    'quantity' => $detail->quantity,
                    'selling_price' => '₱' . number_format($detail->product->selling_price, 2),
                    'product_image' => $detail->product->product_image ?? null,
                    'total_price' => '₱' . number_format($detail->total, 2),
                    'payment_method' => $detail->payment_status == 1 ? 'Cash' :
                            ($detail->payment_status == 2 ? 'Gcash' :
                            ($detail->payment_status == 3 ? 'Cash and Gcash' : 'Unknown')),
                    'subtotalprice'  => $detail->total,
                    'totalprice'     => $totalForSale,
                    'cash'           => $detail->cash,
                    'gcash'          => $detail->gcash,
                    'created_at' => $sale->created_at->copy()->timezone('Asia/Manila')->format('F j, Y g:i A'),
                ];
            });
        });

        return view('admin.pending', [
            'saleData' => $saleData,
            'shops' => $shops,
            'totaldisposes' => $totaldisposes,
            'disposes' => $disposes,
            'selectedShop' => $shopId,
            'viewType' => $viewType,
        ]);
    }

    public function approveAll(Request $request)
    {
        $request->validate([
            'shop_id' => 'required|exists:shops,id',
        ]);

        Sale::where('shop_id', $request->shop_id)
            ->where('sale_status', 0)
            ->update(['sale_status' => 1]);


        return back()->with('success', 'All pending sales approved successfully.');
    }

    public function approvedisposal(Request $request)
    {
        $request->validate([
            'shop_id' => 'required|exists:shops,id',
        ]);

        Dispose::where('shop_id', $request->shop_id)
            ->where('dispose_status', 0)
            ->update(['dispose_status' => 1]);

        return back()->with('success', 'All pending disposes approved successfully.');
    }


    public function declineAll(Request $request)
    {
        $request->validate([
            'shop_id' => 'required|exists:shops,id',
        ]);
    
        $shopId = $request->shop_id;
    
        $sales = Sale::where('shop_id', $shopId)
            ->where('sale_status', 0)
            ->get();
    
        $saleIds = $sales->pluck('id');
    
        $saleDetails = SaleDetail::whereIn('sale_id', $saleIds)->get();
    
        foreach ($saleDetails as $detail) {
            DB::table('product_shop')
                ->where('product_id', $detail->product_id)
                ->where('shop_id', $shopId)
                ->increment('quantity', $detail->quantity);
        }
    
        SaleDetail::whereIn('sale_id', $saleIds)->delete();
        Sale::whereIn('id', $saleIds)->delete();
    
        return back()->with('success', 'All pending sales declined successfully.');
    }

    public function declinedisposal(Request $request)
    {
        $request->validate([
            'shop_id' => 'required|exists:shops,id',
        ]);

        
        $shopId = $request->shop_id;
    
        $disposes = Dispose::where('shop_id', $shopId)
            ->where('dispose_status', 0)
            ->get();

        foreach ($disposes as $dispose) {
            DB::table('product_shop')
                ->where('product_id', $dispose->product_id)
                ->where('shop_id', $shopId)
                ->increment('quantity', 1);
        }
    
        Dispose::where('shop_id', $shopId)->where('dispose_status', 0)->delete();
    
        return back()->with('success', 'All pending disposes declined successfully.');
    }
}
