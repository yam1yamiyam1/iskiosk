<?php

namespace App\Http\Controllers;

use App\Http\Requests\Product\StoreProductRequest;
use App\Http\Requests\Product\UpdateProductRequest;
use App\Models\Brand;
use App\Models\Shop;
use App\Models\Product;
use Illuminate\Http\Request;
use Picqer\Barcode\BarcodeGeneratorHTML;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ProductsExport;
use App\Imports\ProductsImport;
use App\Exports\ProductsTemplate;
use App\Imports\ProductsRestock;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $shopId = $request->shop_id ?? null;
        $brandId = $request->brand_id ?? null;
    
        $query = Product::with(['brand', 'shops' => function ($q) use ($shopId) {
            if ($shopId && $shopId !== 'all') {
                $q->where('shop_id', $shopId);
            }
        }])->select('id', 'name', 'selling_price', 'quantity_alert', 'brand_id', 'product_image');
    
        if ($brandId && $brandId !== 'all') {
            $query->where('brand_id', $brandId);
        }
    
        $products = $query->get();
    
        $brands = Brand::select('id', 'name')->orderBy('name')->get();
        $shops = Shop::select('id', 'name')->orderBy('name')->get();
    
        $productData = $products->map(function ($product) use ($shopId) {
            $quantities = [];
            $shopNames = [];
    
            if ($shopId && $shopId !== 'all') {
                $shop = $product->shops->firstWhere('id', $shopId);
                if ($shop) {
                    $quantities[$shop->id] = $shop->pivot->quantity;
                    $shopNames[$shop->id] = $shop->name;
                }
            } else {
                foreach ($product->shops as $shop) {
                    $quantities[$shop->id] = $shop->pivot->quantity;
                    $shopNames[$shop->id] = $shop->name;
                }
            }
    
            return [
                'id' => $product->id,
                'name' => $product->name,
                'quantities' => $quantities,
                'shop_names' => $shopNames,
                'brand_id' => $product->brand_id ?? 'N/A',
                'brand' => $product->brand->name ?? 'N/A',
                'selling_price' => '₱' . number_format($product->selling_price, 2),
                'quantity_alert' => $product->quantity_alert,
                'product_image' => $product->product_image,
            ];
        });
    
        return view('admin.product', [
            'productData' => $productData,
            'brands' => $brands,
            'shops' => $shops,
            'selectedShop' => $shopId ?? 'all',
        ]);
    }



    public function store(StoreProductRequest $request)
    {
        try {
            $data = $request->except(['product_image', 'quantities']);
            $product = Product::create($data);

            if ($request->hasFile('product_image')) {
                $file = $request->file('product_image');

                if ($file->isValid()) {
                    $filename = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                    $file->storeAs('products', $filename, 'public');

                    $product->update(['product_image' => $filename]);
                } else {
                    return back()->withErrors(['product_image' => 'Invalid image file']);
                }
            }

            if ($request->has('quantities')) {
                foreach ($request->quantities as $shopId => $quantity) {
                    $product->shops()->attach($shopId, ['quantity' => $quantity]);
                }
            }

            return redirect()
                ->back()
                ->with('success', 'Product has been created successfully.');

        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Something went wrong while creating the product']);
        }
    }





    private function generateUniqueCode()
    {
        do {
            $code = 'PC' . strtoupper(uniqid());
        } while (Product::where('code', $code)->exists()); 

        return $code;
    }

    public function show(Product $product)
    {
        $generator = new BarcodeGeneratorHTML();

        $barcode = $generator->getBarcode($product->code, $generator::TYPE_CODE_128);

        return view('products.show', [
            'product' => $product,
            'barcode' => $barcode,
        ]);
    }

    public function update(UpdateProductRequest $request, Product $product)
    {
        $data = $request->except(['product_image', 'quantities']);
        $data['selling_price'] = preg_replace('/[^0-9.]/', '', $data['selling_price']);
        $product->update($data);

        if ($request->hasFile('product_image')) {
            if ($product->product_image) {
                \Storage::disk('public')->delete('products/' . $product->product_image);
            }

            $file = $request->file('product_image');
            $fileName = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('products/', $fileName, 'public');

            $product->update(['product_image' => $fileName]);
        }

        if ($request->has('quantities')) {
            foreach ($request->quantities as $shopId => $quantity) {
                $product->shops()->syncWithoutDetaching([
                    $shopId => ['quantity' => $quantity]
                ]);
            }
        }

        return redirect()
            ->route('products.index')
            ->with('success', 'Product has been updated!');
    }




    public function destroy(Product $product)
    {
        if ($product->product_image) {
            \Storage::disk('public')->delete('products/' . $product->product_image);
        }

        $product->shops()->detach();

        $product->delete();

        return redirect()
            ->route('products.index')
            ->with('success', 'Product has been deleted!');
    }

    public function export(Request $request)
    {
        return Excel::download(new ProductsExport($request->shop_id), 'Stocks_' . now()->setTimezone('Asia/Manila')->format('Y-m-d') . '.xlsx');
    }

    public function import(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv',
        ]);
    
        $shopId = $request->input('shop_id');
        $import = new ProductsImport($shopId);
        Excel::import($import, $request->file('file'));
    
        if ($import->updated === 0) {
            return redirect()->route('products.index')->with('error', 'No product quantities were changed. Please check your file.');
        }
    
        return redirect()->route('products.index')->with('success', 'Products quantity updated successfully!');
    }

    
    public function template(Request $request)
    {
        return Excel::download(new ProductsTemplate($request->shop_id), 'ProductTemplate_' . now()->setTimezone('Asia/Manila')->format('Y-m-d') . '.xlsx');
    }

    public function restock(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv',
        ]);
    
        $shopId = $request->input('shop_id');
        $import = new ProductsRestock($shopId);
        Excel::import($import, $request->file('file'));
    
        if ($import->updated === 0) {
            return redirect()->route('products.index')->with('error', 'No products were restocked. Please check your file.');
        }
    
        return redirect()->route('products.index')->with('success', 'The products have been restocked successfully!');
    }
}
