<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Http\Requests\Brand\StoreBrandRequest;
use App\Http\Requests\Brand\UpdateBrandRequest;
use Illuminate\Support\Str;

class BrandController extends Controller
{
    public function index()
    {
        $brands = Brand::select('id', 'name', 'slug', 'brand_image')
            ->limit(50)
            ->get();

        $brandData = $brands->map(function ($brand) {
            return [
                'id' => $brand->id,
                'name' => $brand->name,
                'slug' => $brand->slug,
                'brand_image' => $brand->brand_image,
            ];
        });

        return view('admin.brand', [
            'brandData' => $brandData,
        ]);
    }

    public function store(StoreBrandRequest $request)
    {
        $data = $request->validated();
        $slug = Str::slug($data['name']);

        $existingSlug = Brand::where('slug', $slug)->first();

        if ($existingSlug) {
            $slug = $slug . '-' . time();
        }

        $data['slug'] = $slug;

        $brand = Brand::create($data);

        if ($request->hasFile('brand_image')) {
            $file = $request->file('brand_image');

            if ($file->isValid()) {
                $filename = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                $file->storeAs('brands', $filename, 'public');

                $brand->update([
                    'brand_image' => $filename
                ]);
            } else {
                return back()->withErrors(['brand_image' => 'Invalid image file']);
            }
        }

        return redirect()->route('brands.index')->with('success', 'Brand has been created!');
    }


    public function show(Brand $brand)
    {
        return view('brands.show', [
            'brand' => $brand
        ]);
    }

    public function update(UpdateBrandRequest $request, Brand $brand)
    {
        $data = $request->validated();
        $data['slug'] = Str::slug($data['name']);

        $brand->update($data);

        if ($request->hasFile('brand_image')) {
            if ($brand->brand_image) {
                \Storage::disk('public')->delete('brands/' . $brand->brand_image);
            }

            $file = $request->file('brand_image');
            $fileName = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
            $file->storeAs('brands/', $fileName, 'public');

            $brand->update([
                'brand_image' => $fileName
            ]);
        }

        return redirect()
            ->route('brands.index')
            ->with('success', 'Brand has been updated!');
    }


    public function destroy(Brand $brand)
    {
        $brand->delete();

        return redirect()
            ->route('brands.index')
            ->with('success', 'Brand has been deleted!');
    }
}
