<?php

namespace App\Http\Controllers;

use App\Models\Shop;
use App\Http\Requests\Shop\StoreShopRequest;
use App\Http\Requests\Shop\UpdateShopRequest;
use Illuminate\Support\Str;

class ShopController extends Controller
{
    public function index()
    {
        $shops = Shop::select('id', 'name', 'slug')
            ->limit(50)
            ->get();

        $shopData = $shops->map(function ($shop) {
            return [
                'id' => $shop->id,
                'name' => $shop->name,
                'slug' => $shop->slug,
            ];
        });

        return view('admin.shop', [
            'shopData' => $shopData,
        ]);
    }

    public function store(StoreShopRequest $request)
    {
        $data = $request->validated();
        $slug = Str::slug($data['name']);

        $existingSlug = Shop::where('slug', $slug)->first();

        if ($existingSlug) {
            $slug = $slug . '-' . time();
        }

        $data['slug'] = $slug;

        $shop = Shop::create($data);

        return redirect()->route('shops.index')->with('success', 'Shop has been created!');
    }


    public function show(Shop $shop)
    {
        return view('shops.show', [
            'shop' => $shop
        ]);
    }

    public function update(UpdateShopRequest $request, Shop $shop)
    {
        $data = $request->validated();
        $data['slug'] = Str::slug($data['name']);

        $shop->update($data);

        return redirect()
            ->route('shops.index')
            ->with('success', 'Shop has been updated!');
    }


    public function destroy(Shop $shop)
    {
        $shop->delete();

        return redirect()
            ->route('shops.index')
            ->with('success', 'Shop has been deleted!');
    }
}
