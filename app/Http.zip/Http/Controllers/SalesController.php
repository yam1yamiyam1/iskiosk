<?php

namespace App\Http\Controllers;

use App\Enums\SaleStatus;
use App\Http\Requests\Sale\SaleStoreRequest;
use App\Models\User;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Shop;
use App\Models\Dispose;
use App\Models\Product;
use Carbon\Carbon;
use Gloudemans\Shoppingcart\Facades\Cart;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SalesController extends Controller
{
    public function index()
    {
        $sales = Sale::latest()->get();

        return view('sales.index', [
            'sales' => $sales,
        ]);
    }

    public function create()
    {
        Cart::instance('sale')
            ->destroy();

        return view('sales.create', [
            'carts' => Cart::content(),
            'users' => User::all(['id', 'name']),
            'products' => Product::with(['brand', 'unit'])->get(),
        ]);
    }

    public function store(SaleStoreRequest $request)
    {
        $Sale = Sale::create($request->all());

        // Create Sale Details
        $contents = Cart::instance('sale')->content();
        $oDetails = [];

        foreach ($contents as $content) {
            $oDetails['sale_id'] = $sale['id'];
            $oDetails['product_id'] = $content->id;
            $oDetails['quantity'] = $content->qty;
            $oDetails['unitcost'] = $content->price;
            $oDetails['total'] = $content->subtotal;
            $oDetails['created_at'] = Carbon::now();

            SaleDetail::insert($oDetails);
        }

        // Delete Cart Sopping History
        Cart::destroy();

        return redirect()
            ->route('sales.index')
            ->with('success', 'Sale has been created!');
    }

    public function show(Sale $Sale)
    {
        $sale->loadMissing(['user', 'details'])->get();

        return view('sales.show', [
            'sale' => $sale,
        ]);
    }

    public function update(Sale $Sale, Request $request)
    {
        // TODO refactoring

        // Reduce the stock
        $products = SaleDetail::where('sale_id', $sale)->get();

        foreach ($products as $product) {
            Product::where('id', $product->product_id)
                ->update(['quantity' => DB::raw('quantity-' . $product->quantity)]);
        }

        $sale->update([
            'sale_status' => SaleStatus::COMPLETE,
        ]);

        return redirect()
            ->route('sales.complete')
            ->with('success', 'Sale has been completed!');
    }

    public function destroy(Sale $Sale)
    {
        $sale->delete();
    }

    public function downloadInvoice($sale)
    {
        $sale = sale::with(['user', 'details'])
            ->where('id', $sale)
            ->first();

        return view('sales.print-invoice', [
            'sale' => $sale,
        ]);
    }

    public function completedSales(Request $request)
    {
        $shopId = $request->shop_id ?? Shop::orderBy('name')->first()?->id ?? null;
        $viewType = $request->view_type ?? 'sale';
        
        $startDate = $request->startDate ?? Carbon::now('Asia/Manila')->format('Y-m-d');
        $endDate = $request->endDate ?? Carbon::now('Asia/Manila')->format('Y-m-d');
        
        $shops = Shop::select('id', 'name')->orderBy('name')->get();

        if (!$shopId) {
            return view('admin.records', [
                'saleData' => collect(),
                'shops' => $shops,
                'selectedShop' => '',
                'totaldisposes' => 0,
                'disposes' => collect(),
                'viewType' => $viewType,
                'startDate' => $startDate,
                'endDate' => $endDate
            ]);
        }

        $disposesQuery = Dispose::with(['product.brand'])
            ->where('shop_id', $shopId)
            ->where('dispose_status', 1);

        if ($startDate && $endDate) {
            $disposesQuery->whereBetween(\DB::raw('CONVERT_TZ(created_at, "+00:00", "+08:00")'), [
                $startDate . ' 00:00:00', 
                $endDate . ' 23:59:59'
            ]);
        }

        $disposes = $disposesQuery->get()->map(function ($dispose) {
            $dispose->formatted_created_at = $dispose->created_at
                ->copy()
                ->timezone('Asia/Manila')
                ->format('F j, Y g:i A');
            return $dispose;
        });

        $totaldisposes = $disposes->count();

        $salesQuery = Sale::with(['details.product.brand', 'user'])
            ->where('shop_id', $shopId)
            ->where('sale_status', 1)
            ->whereHas('details', function ($q) {
                $q->where('order_status', 1);
            });

        if ($startDate && $endDate) {
            $salesQuery->whereBetween(\DB::raw('CONVERT_TZ(created_at, "+00:00", "+08:00")'), [
                $startDate . ' 00:00:00', 
                $endDate . ' 23:59:59'
            ]);
        }

        $sales = $salesQuery->get();

        if ($viewType === 'product') {
            $productSummary = [];

            foreach ($sales as $sale) {
                foreach ($sale->details as $detail) {
                    $productId = $detail->product_id;
                    if (!isset($productSummary[$productId])) {
                        $productSummary[$productId] = [
                            'product_name' => $detail->product->name ?? 'N/A',
                            'brand_name' => $detail->product->brand->name ?? 'N/A',
                            'product_image' => $detail->product->product_image ?? null,
                            'quantity' => 0,
                            'remquantity' => $detail->product->shops->firstWhere('id', $shopId)?->pivot->quantity ?? 0,
                            'total' => 0,
                            'selling_price' => $detail->product->selling_price ?? 0,
                        ];
                    }

                    $productSummary[$productId]['quantity'] += $detail->quantity;
                    $productSummary[$productId]['total'] += $detail->total;
                }
            }

            return view('admin.records', [
                'saleData' => collect($productSummary),
                'shops' => $shops,
                'selectedShop' => $shopId,
                'totaldisposes' => $totaldisposes,
                'disposes' => $disposes,
                'viewType' => $viewType,
                'startDate' => $startDate,
                'endDate' => $endDate
            ]);
        }

        $saleData = $sales->flatMap(function ($sale) {
            $totalForSale = $sale->details->sum('total');
            $staffName = $sale->user ? $sale->user->fname . ' ' . $sale->user->lname : 'N/A';
            return $sale->details->map(function ($detail) use ($sale, $totalForSale, $staffName) {
                return [
                    'order_id' => $detail->id,
                    'sale_id' => $sale->id,
                    'staff_name'     => $staffName,
                    'product_name' => $detail->product->name ?? 'N/A',
                    'brand_name' => $detail->product->brand->name ?? 'N/A',
                    'quantity' => $detail->quantity,
                    'selling_price' => '₱' . number_format($detail->product->selling_price, 2),
                    'product_image' => $detail->product->product_image ?? null,
                    'total_price' => '₱' . number_format($detail->total, 2),
                    'payment_method' => $detail->payment_status == 1 ? 'Cash' :
                            ($detail->payment_status == 2 ? 'Gcash' :
                            ($detail->payment_status == 3 ? 'Cash and Gcash' : 'Unknown')),
                    'subtotalprice'  => $detail->total,
                    'totalprice'     => $totalForSale,
                    'cash'           => $detail->cash,
                    'gcash'          => $detail->gcash,
                    'created_at' => $sale->created_at->copy()->timezone('Asia/Manila')->format('F j, Y g:i A'),
                ];
            });
        });

        return view('admin.records', [
            'saleData' => $saleData,
            'shops' => $shops,
            'selectedShop' => $shopId,
            'totaldisposes' => $totaldisposes,
            'disposes' => $disposes,
            'viewType' => $viewType,
            'startDate' => $startDate,
            'endDate' => $endDate
        ]);
    }

}
