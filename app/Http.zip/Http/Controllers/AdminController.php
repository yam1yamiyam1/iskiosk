<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Role;
use App\Models\Shop;
use App\Models\Engage;
use App\Models\Report;
use App\Models\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AdminController extends Controller
{
    public function index()
    {
        $users = User::with('roles', 'shop')->get();
        $shops = Shop::select('id', 'name')->orderBy('name')->get();
        return view('admin.user', compact('users', 'shops'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'fname' => ['required', 'regex:/^[A-Za-z\s.-]{3,}$/'],
            'mi' => ['nullable', 'max:2', 'regex:/^[A-Za-z\s.-]{1,2}$/'],
            'lname' => ['required', 'regex:/^[A-Za-z\s.-]{3,}$/'],
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif', 'max:2048'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'min:8', 'confirmed', 'regex:/^\S*$/'],
            'role' => ['required', 'in:0,1'],
            'status' => ['required', 'in:0,1'],
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $data = $request->except(['image', 'role', 'password_confirmation']);
            $data['password'] = Hash::make($request->password);
            $data['status'] = $request->input('status');

            $user = User::create($data);

            if ($request->hasFile('image')) {
                $file = $request->file('image');

                if ($file->isValid()) {
                    $filename = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                    $file->storeAs('users', $filename, 'public');

                    $user->update(['image' => $filename]);
                } else {
                    return back()->withErrors(['image' => 'Invalid image file']);
                }
            }

            $role = Role::create([
                'role' => $request['role'] ?? 0,
                'name' => $user->fname,
            ]);
            
            
            $user->roles()->attach($role->id);

            return redirect()->back()->with('success', 'User has been created.');
        } catch (\Exception $e) {
            return back()->withErrors(['error' => 'Something went wrong while creating the user.']);
        }
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $request->validate([
            'fname' => ['required', 'regex:/^[A-Za-z\s.-]{3,}$/'],
            'mi' => ['nullable', 'max:2', 'regex:/^[A-Za-z\s.-]{1,2}$/'],
            'lname' => ['required', 'regex:/^[A-Za-z\s.-]{3,}$/'],
            'image' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif', 'max:2048'],
            'email' => ['required', 'email', Rule::unique('users')->ignore($user->id)],
            'password' => ['nullable', 'min:8', 'confirmed', 'regex:/^\S*$/'],
            'role' => ['required', 'in:0,1'],
            'status' => ['required', 'in:0,1'],
            'shop' => ['nullable', 'exists:shops,id'],
        ]);


        $user->fname = $request->input('fname');
        $user->mi = $request->input('mi');
        $user->lname = $request->input('lname');
        $user->email = $request->input('email');
        $user->status = $request->input('status');

        if ($request->filled('password')) {
            $user->password = bcrypt($request->input('password'));
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            if ($file->isValid()) {
                $filename = hexdec(uniqid()) . '.' . $file->getClientOriginalExtension();
                $file->storeAs('users', $filename, 'public');
                $user->image = $filename;
            } else {
                return back()->withErrors(['image' => 'Invalid image file']);
            }
        }

        if ($user->roles()->exists()) {
            $userRole = $user->roles()->first();
            $userRole->role = $request->input('role');
            $userRole->save();
        }

        if ($request->input('role') == 0) {
            $user->shop_id = $request->input('shop');
        } else {
            $user->shop_id = null;
        }

        $user->save();

        return redirect()->route('users.index')->with('success', 'User updated successfully.');
    }



    
    
    public function disable(Request $request, $id)
    {
        $user = User::findOrFail($id);
        
        // $engage = Engage::where('engage_id', $user->id)
        //         ->whereNotIn('status', [5, 1])
        //         ->first();
        // $engage1 = Engage::where('user_id', $user->id)
        //         ->whereNotIn('status', [5, 1])
        //         ->first();
        // $report = Report::where('user_id', $user->id)->delete();
        // $report1 = Report::where('report_user_id', $user->id)->delete();
        // $engage = Engage::where('engage_id', $user->id)->delete();
        // $engage1 = Engage::where('user_id', $user->id)->delete();
        // $user->roles()->delete();
        // $user->delete();
        
        // return redirect('/admin/accounts')->with('status', 'Account has been successfully deleted.');
        
        if ($user->status == 0) {
            $user->status = 1;
            flash()->success('Success', 'Account Enabled Successfully');
        }
        else {
            $user->status = 0;
            if ($user->suspended_at != null || $user->suspended_at != "") {
                $user->suspended_at = null;
                $user->suspension_end_at = null;
            }
            flash()->success('Success', 'Account Disabled Successfully');
        }
        $user->save();
    
        return back()->with('success');
    }
    
    public function suspend(Request $request, $id)
    {
        $user = User::findOrFail($id);
    
        $request->validate([
            'suspension_duration' => 'required|in:3_days,1_week,1_month,3_months,cancel',
        ]);
    
        $duration = $request->input('suspension_duration');
    
        if ($duration === 'cancel') {
            $user->status = 1;
            $user->suspended_at = null;
            $user->suspension_end_at = null;
            $user->save();
    
            flash()->success('Success', 'Suspension cancelled successfully.');
            return back()->with('success');
        }
    
        switch ($duration) {
            case '3_days':
                $suspensionEndDate = now('Asia/Manila')->addDays(3);
                break;
            case '1_week':
                $suspensionEndDate = now('Asia/Manila')->addWeek();
                break;
            case '1_month':
                $suspensionEndDate = now('Asia/Manila')->addMonth();
                break;
            case '3_months':
                $suspensionEndDate = now('Asia/Manila')->addMonths(3);
                break;
            default:
                $suspensionEndDate = now('Asia/Manila')->addDays(3);
                break;
        }
    
        $user->suspended_at = now('Asia/Manila');
        $user->suspension_end_at = $suspensionEndDate;
        $user->status = 2;
        $user->save();
    
        flash()->success('Success', 'User suspended successfully.');
        return back()->with('success');
    }

    public function warning(Request $request, $id) 
    {
        $user = User::findOrFail($id);
        $reason = $request->input('warning_notif');
    
        $warningMessage = match ($reason) {
            'scam' => "Warning: Your account has been flagged for scam-related activities. Please adhere to our policies to avoid further action.",
            'offensive' => "Warning: We've received reports of offensive language in your chats. Please communicate respectfully.",
            'privacy' => "Warning: Your account has been flagged for violating data privacy standards. Ensure compliance with privacy rules.",
            'others' => "Warning: Your account has received a report for inappropriate behavior. Review our community guidelines carefully.",
            default => "Warning: Your account has received a report. Please comply with our community standards.",
        };
        
        Notification::create([
            'user_id' => $user->id,
            'notification_user' => "Admin",
            'notification_userid' => "1",
            'notification' => $warningMessage,
            'learner' => '0',
        ]);
    
        flash()->success('Success', 'Warning notification sent successfully.');
        return back()->with('success');
    }
    
    public function accounts() {
        
        $users = User::where('id', '!=', auth()->user()->id)
            ->whereHas('roles', function ($query) {
                $query->whereIn('role', [0, 1]);
            })
            ->get();

        return view('admin.accountmanagement')->with(['users' => $users]);
    }

    public function destroy($id)
    {
        $user = User::findOrFail($id);
    
        if (auth()->check() && auth()->id() == $user->id) {
            return redirect()->back()->with('error', 'You cannot delete your own account.');
        }
    
        if ($user->image && \Storage::disk('public')->exists('users/' . $user->image)) {
            \Storage::disk('public')->delete('users/' . $user->image);
        }
    
        $user->delete();
    
        return redirect()->back()->with('success', 'User has been deleted.');
    }
}
