<?php

namespace App\Models;

use App\Enums\OrderStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Sale extends Model
{
    use HasFactory;

    protected $guarded = [
        'id',
    ];

    protected $fillable = [
        'user_id',
        'shop_id',
        'sale_date',
        'sale_status',
    ];

    protected $casts = [
        'sale_date'    => 'date',
        'created_at'    => 'datetime',
        'updated_at'    => 'datetime',
        'sale_status'  => 'int'
    ];

    public function User(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function shop(): BelongsTo
    {
        return $this->belongsTo(Shop::class);
    }

    public function details(): HasMany
    {
        return $this->hasMany(SaleDetail::class);
    }

    public function scopeSearch($query, $value): void
    {
        $query->where('sale_status', 'like', "%{$value}%");
    }
}
