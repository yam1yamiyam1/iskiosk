@extends('layouts.tabler')

@section('content')
<style>
.no-flex {
    display: block !important;
    align-items: initial !important;
}
</style>

<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">Products</h2>
            </div>
        </div>
        <div class="row g-2 align-items-center">
            <div class="col-auto ms-auto d-print-none" style="border: 2px solid #c3c3c3; border-radius: 5px; padding: 2px">
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#importProductsModal">
                        Import Products
                    </button>
                    <a href="{{ route('products.export', ['shop_id' => $selectedShop]) }}" class="btn btn-primary" style="background-color: #720100;">
                        <x-icon.floppy-disk /> Export Products
                    </a>
                </div>
            </div>
        </div>
        <div class="row g-2 align-items-center mt-2">
            <div class="col-auto ms-auto d-print-none">
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-primary d-sm-inline-block" data-bs-toggle="modal" data-bs-target="#addProductModal" style="background-color: #720100;">
                        <x-icon.plus />
                        Add Product
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page-body">
    <div class="container-xl">
        <form method="GET" action="{{ route('product.index') }}" class="mb-4">
            <div class="row g-2">
                <div class="col-md-4">
                    <select name="shop_id" class="form-select" onchange="this.form.submit()">
                        <option value="all" {{ $selectedShop === 'all' ? 'selected' : '' }}>All Shops</option>
                        @foreach($shops as $shop)
                            <option value="{{ $shop->id }}" {{ $selectedShop == $shop->id ? 'selected' : '' }}>
                                {{ $shop->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="brand_id" class="form-select" onchange="this.form.submit()">
                        <option value="all" {{ request('brand_id') === 'all' ? 'selected' : '' }}>All Brands</option>
                        @foreach($brands as $brand)
                            <option value="{{ $brand->id }}" {{ request('brand_id') == $brand->id ? 'selected' : '' }}>
                                {{ $brand->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-auto ms-auto d-print-none" style="border: 2px solid #c3c3c3; border-radius: 5px; padding: 2px">
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#restockProductsModal">
                            Restock
                        </button>
                        <a href="{{ route('products.template', ['shop_id' => $selectedShop]) }}" class="btn btn-primary">
                            <x-icon.floppy-disk /> Excel Template
                        </a>
                    </div>
                </div>
            </div>
        </form>

        <div class="row row-deck row-cards">
            <div class="col-12 table-responsive no-flex">
                @if (count($productData) === 0)
                    <div class="alert alert-warning" role="alert">
                        No products available.
                    </div>
                @else
                    <table id="products-table" class="table table-striped datatable" style="width:100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Quantity</th>
                                <th>Brand</th>
                                <th>Selling Price</th>
                                <th>Quantity Alert</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($productData as $index => $product)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>
                                        @if ($product['product_image'])
                                            <img src="{{ asset('storage/products/' . $product['product_image']) }}" alt="Image" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                                        @else
                                            <span class="text-muted">No Image</span>
                                        @endif
                                    </td>
                                    <td>{{ $product['name'] }}</td>
                                    <td>
                                        @if ($selectedShop === 'all')
                                            @foreach ($shops as $shop)
                                                <div>
                                                    <strong>{{ $shop->name }}:</strong>
                                                    {{ $product['quantities'][$shop->id] ?? 0 }}
                                                </div>
                                            @endforeach
                                        @else
                                            {{ $product['quantities'][$selectedShop] ?? 0 }}
                                        @endif
                                    </td>
                                    <td>{{ $product['brand'] }}</td>
                                    <td>{{ $product['selling_price'] }}</td>
                                    <td>{{ $product['quantity_alert'] }}</td>
                                    <td>
                                        <a href="#" class="text-primary me-2" data-bs-toggle="modal" data-bs-target="#editProductModal{{ $product['id'] }}">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="#" class="text-danger" data-bs-toggle="modal" data-bs-target="#deleteProductModal{{ $product['id'] }}">
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>
        </div>
    </div>
</div>

@include('includes.productadd')
@include('includes.quantityimport')
@include('includes.quantityrestock')
@foreach ($productData as $product)
    @include('includes.productedit')
    @include('includes.productdelete')
@endforeach
@endsection

@push('styles')
    {{-- DataTables Bootstrap 5 CSS --}}
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" />
@endpush

@push('page-libraries')
<script src="{{ asset('dist/libs/apexcharts/dist/apexcharts.min.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/js/jsvectormap.min.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/maps/world.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/maps/world-merc.js') }}" defer></script>
@endpush

@push('page-scripts')
    {{-- jQuery needed by DataTables --}}
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    {{-- DataTables JS --}}
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $('#products-table').DataTable({
            pageLength: 10,
            lengthMenu: [[5, 10, 25, 50, 100, -1], [5, 10, 25, 50, 100, "All"]],
            columnDefs: [
                { orderable: false, targets: [1, 7] }
            ],
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search products...",
                infoEmpty: "No entries to show",
            },
            infoCallback: function(settings, start, end, max, total, pre) {
                if (settings._iDisplayLength == -1) {
                    return `Showing all ${total} products`;
                }
                return `Showing ${start} to ${end} of ${total} products`;
            },
            autoWidth: false
        });

    </script>
@endpush
