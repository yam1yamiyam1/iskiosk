@extends('layouts.tabler')

@section('content')
<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <h2 class="page-title">Products</h2>
            </div>
            <div class="col-auto ms-auto d-print-none">
                <div class="d-flex gap-2">
                    <a href="{{ route('sales.completed') }}" class="btn btn-outline-secondary d-sm-inline-block">
                        Clear Filter
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="disposalsModal" tabindex="-1" aria-labelledby="disposalsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="disposalsModalLabel">Pending Disposals</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                @if($disposes->count() > 0)
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Product</th>
                                    <th>Disposed On</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($disposes as $dispose)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>
                                        @if ($dispose->product->product_image)
                                            <img src="{{ asset('storage/products/' . $dispose->product->product_image) }}" alt="Image" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                                        @else
                                            <span class="text-muted">No Image</span>
                                        @endif
                                    </td>

                                    <td>{{ $dispose->product->name ?? 'N/A' }}</td>
                                    <td>{{ $dispose->formatted_created_at }}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="alert alert-info mb-0">
                        No disposals for this shop.
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

@if ($viewType == 'product')
    @include('admin.partials.record_view_by_product', ['saleData' => $saleData])
@else
    @include('admin.partials.record_view_by_sale', ['saleData' => $saleData])
@endif
@endsection

@push('page-libraries')
<script src="{{ asset('dist/libs/apexcharts/dist/apexcharts.min.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/js/jsvectormap.min.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/maps/world.js') }}" defer></script>
<script src="{{ asset('dist/libs/jsvectormap/dist/maps/world-merc.js') }}" defer></script>
@endpush

@pushonce('page-scripts')
<script>
    const advancedSearchInput = document.getElementById('advanced-search-input');
    const table = document.querySelector('.table tbody');

    const search = (value) => {
        const phrase = value.trim().toLowerCase();
        const rows = Array.from(table.querySelectorAll('tr.data-row'));

        rows.forEach(row => {
            const id = row.children[0]?.textContent.toLowerCase() || '';
            const name = row.children[2]?.textContent.toLowerCase() || '';
            const quantity = row.children[3]?.textContent.toLowerCase() || '';
            const brand = row.children[4]?.textContent.toLowerCase() || '';
            const selling_price = row.children[5]?.textContent.toLowerCase() || '';

            const match =
                id.includes(phrase) ||
                name.includes(phrase) ||
                quantity.includes(phrase) ||
                brand.includes(phrase) ||
                selling_price.includes(phrase);

            row.style.display = match ? '' : 'none';
        });

        const allRows = Array.from(table.querySelectorAll('tr'));
        let currentSaleId = null;
        let visibleCount = 0;

        allRows.forEach((row) => {
            const isDataRow = row.classList.contains('data-row');

            if (isDataRow) {
                const idCell = row.children[0];
                if (idCell && idCell.textContent.trim() !== '') {
                    currentSaleId = idCell.textContent.trim();
                }

                if (row.style.display !== 'none') {
                    visibleCount++;
                }
            }

            const isTotalRow = !isDataRow && row.children[0]?.textContent?.includes('Total for Sale ID');
            if (isTotalRow) {
                const shouldShow = visibleCount > 0;
                row.style.display = shouldShow ? '' : 'none';
                visibleCount = 0;
            }
        });
    };

    advancedSearchInput.addEventListener('input', (e) => {
        search(e.target.value);
    });
</script>
@endpushonce
