<div class="page-body">
    <div class="container-xl">
        <div class="row g-2 mb-3">
            <div class="col-auto ms-auto d-print-none">
                <div class="btn-list position-relative">
                    <a href="javascript:void(0);" class="btn btn-danger position-relative" data-bs-toggle="modal" data-bs-target="#disposalsModal">
                        <i class="ti ti-trash"></i> Disposals
                        @if($totaldisposes > 0)
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                                {{ $totaldisposes }}
                            </span>
                        @endif
                    </a>
                </div>
            </div>
        </div>

        <form method="GET" action="{{ route('sales.pending') }}" class="mb-4">
            <div class="row g-2">
                <div class="col-md-4">
                    <select name="shop_id" class="form-select" onchange="this.form.submit()">
                        @foreach($shops as $shop)
                            <option value="{{ $shop->id }}" {{ $selectedShop == $shop->id ? 'selected' : '' }}>
                                {{ $shop->name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="view_type" class="form-select" onchange="this.form.submit()">
                        <option value="sale" {{ $viewType == 'sale' ? 'selected' : '' }}>View by Sale</option>
                        <option value="product" {{ $viewType == 'product' ? 'selected' : '' }}>View by Product</option>
                        <!-- Add more view types here -->
                    </select>
                </div>
            </div>
        </form>

        <div class="row row-deck row-cards">
            <div class="col-12">
                <div class="input-group mb-4">
                    <input type="text" class="form-control" id="advanced-search-input" placeholder="Search..." />
                    <button class="btn btn-primary" style="background-color: #720100; id="advanced-search-button" type="button">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>

            @php
                $currentTotal = 0;
                $totalAllSales = 0;
            @endphp

            <div class="col-12 table-responsive">
                @if (count($saleData) === 0)
                    <div class="alert alert-warning" role="alert">
                        No sales are pending at the moment.
                    </div>
                @else
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Brand</th>
                            <th>Sold Quantity</th>
                            <th>Remaining Quantity</th>
                            <th>Selling Price</th>
                            <th>Sub Total Price</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($saleData as $index => $sale)
                            @php
                                $currentTotal = floatval(str_replace(['₱', ','], '', $sale['total']));
                                $totalAllSales += floatval(str_replace(['₱', ','], '', $sale['total']));
                            @endphp
                            <tr class="data-row">
                                <td>{{ $index + 1 }}</td>
                                <td>
                                    @if ($sale['product_image'])
                                        <img src="{{ asset('storage/products/' . $sale['product_image']) }}" alt="Image" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                                    @else
                                        <span class="text-muted">No Image</span>
                                    @endif
                                </td>
                                <td>{{ $sale['product_name'] }}</td>
                                <td>{{ $sale['brand_name'] }}</td>
                                <td>{{ $sale['quantity'] ?? 0 }}</td>
                                <td>{{ $sale['remquantity'] ?? 0 }}</td>
                                <td>₱{{ number_format($sale['selling_price'], 2) }}</td>
                                <td>₱{{ number_format($currentTotal, 2) }}</td>
                                <td>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>

            <div class="alert alert-info text-end">
                <strong>Total for All Sales: </strong> ₱{{ number_format($totalAllSales, 2) ?? '0.00' }}
            </div>
        </div>
    </div>
</div>