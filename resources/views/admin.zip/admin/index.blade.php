@extends('layouts.tabler')

@section('content')
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <div class="page-pretitle">Overview</div>
                    <h2 class="page-title">Dashboard</h2>
                </div>
            </div>
        </div>
    </div>

    <div class="page-body">
        <div class="container-xl">
            <div class="row row-deck row-cards">
                <div class="col-12">
                    <div class="row row-cards">
                        <div class="col-sm-6 col-lg-3">
                            <a href="{{ route('shops.index') }}" class="text-decoration-none">
                                <div class="card card-sm">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <span class="avatar text-white" style="background-color: #720100;">
                                                    <i class="fa-solid fa-shop"></i>
                                                </span>
                                            </div>
                                            <div class="col">
                                                <div class="font-weight-medium">
                                                    {{ $shops }} Shops
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <a href="{{ route('products.store') }}" class="text-decoration-none">
                                <div class="card card-sm">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <span class="avatar text-white" style="background-color: #720100;">
                                                    <i class="fa-solid fa-boxes-stacked"></i>
                                                </span>
                                            </div>
                                            <div class="col">
                                                <div class="font-weight-medium">
                                                    {{ $products }} Products
                                                </div>
                                                <div class="text-muted">
                                                    {{ $brands }} brands
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <a href="{{ route('sales.pending') }}" class="text-decoration-none">
                                <div class="card card-sm">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <span class="bg-green text-white avatar">
                                                    <i class="fa-solid fa-clipboard-list"></i>
                                                </span>
                                            </div>
                                            <div class="col">
                                                <div class="font-weight-medium">
                                                    {{ $pendingsales }} Pending Sales
                                                </div>
                                                <div class="text-muted">
                                                    {{ $completedSales }} Approved Sales
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-sm-6 col-lg-3">
                            <a href="{{ route('users.index') }}" class="text-decoration-none">
                                <div class="card card-sm">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <span class="bg-green text-white avatar">
                                                    <i class="fa-solid fa-users-gear"></i>
                                                </span>
                                            </div>
                                            <div class="col">
                                                <div class="font-weight-medium">
                                                    {{ $users }} Staff/s
                                                </div>
                                                <div class="text-muted">
                                                    {{ $admins }} Admin/s
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h3 class="card-title">Sales Overview</h3>
                            <form method="GET" action="{{ route('dashboard') }}">
                                <select name="range" onchange="this.form.submit()" class="form-select w-auto">
                                    <option value="daily" {{ $range == 'daily' ? 'selected' : '' }}>Last 7 Days</option>
                                    <option value="weekly" {{ $range == 'weekly' ? 'selected' : '' }}>Last 5 Weeks</option>
                                    <option value="monthly" {{ $range == 'monthly' ? 'selected' : '' }}>Last 6 Months</option>
                                    <option value="yearly" {{ $range == 'yearly' ? 'selected' : '' }}>Last 6 Years</option>
                                </select>
                            </form>
                        </div>
                        <div class="card-body">
                            <div id="sales-chart" style="height: 300px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Top-Performing Products</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="topProductsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

@push('page-scripts')
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const options = {
            chart: {
                type: "area",
                height: 300,
                toolbar: { show: false }
            },
            dataLabels: { enabled: false },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            series: [{
                name: "Sales",
                data: @json($salesGraphData['sales'])
            }],
            xaxis: {
                categories: @json($salesGraphData['dates']),
                labels: { rotate: -45 }
            },
            colors: ["#206bc4"],
            fill: {
                type: "gradient",
                gradient: {
                    shadeIntensity: 1,
                    opacityFrom: 0.7,
                    opacityTo: 0.2,
                    stops: [0, 90, 100]
                }
            },
            tooltip: {
                x: { format: 'dd MMM yyyy' },
                y: {
                    formatter: function (val) {
                        return '₱' + val.toLocaleString();
                    }
                }
            }
        };

        const chart = new ApexCharts(document.querySelector("#sales-chart"), options);
        chart.render();
    });

    document.addEventListener("DOMContentLoaded", function () {
        const ctx = document.getElementById('topProductsChart').getContext('2d');
        const topProductsData = @json($topProductsData);
    
        const labels = topProductsData.map(product => product.name);
        const data = topProductsData.map(product => product.sales);
    
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Sales',
                    data: data,
                    backgroundColor: [
                        '#ff0d0b', '#36a2eb', '#ffcd56', '#4bc0c0', '#9966ff', '#ff9f40'
                    ],
                    borderColor: '#333',
                    borderWidth: 1,
                    borderRadius: 5,
                    barPercentage: 0.6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                return `${context.parsed.x.toLocaleString()} pcs`;
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'Top-Performing Products',
                        font: {
                            size: 18,
                            weight: 'bold'
                        }
                    }

                },
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Sales (pcs)'
                        },
                        ticks: {
                            precision: 0
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Product Name'
                        }
                    }
                }
            }
        });
    });
</script>
@endpush


