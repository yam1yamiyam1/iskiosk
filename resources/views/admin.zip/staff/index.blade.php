@extends('layouts.tabler')

@section('content')
    <div class="page-header d-print-none">
        <div class="container-xl">
            <div class="row g-2 align-items-center">
                <div class="col">
                    <div class="page-pretitle">
                        {{ auth()->user()->shop->name ?? 'No shop assigned' }}
                    </div>
                    <h2 class="page-title">
                        Brands
                    </h2>
                </div>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="input-group mb-4">
                        <input type="text" class="form-control" id="advanced-search-input" placeholder="Search..." />
                        <button class="btn btn-primary" style="background-color: #720100;" id="advanced-search-button" type="button">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </div>
                </div>
                <div class="listBrand col-12">
                    @if (count($brandData) === 0)
                        <div class="alert alert-warning" role="alert">
                            No brands available.
                        </div>
                    @else
                        @foreach ($brandData as $index => $brand)
                            <a href="{{ route('home.brand', $brand['id']) }}" class="item">
                                <img src="{{ $brand['brand_image'] ? asset('storage/brands/' . $brand['brand_image']) : asset('storage/brands/p1.jpg') }}" alt="">
                                <h2>{{ $brand['name'] }}</h2>
                            </a>
                        @endforeach
                    @endif
                </div>
            </div>
        </div>
    </div>
    <div class="contact-container">
        <button class="expand-btn" aria-label="Open contact form">
            <i class="fa-solid fa-briefcase briefcase-icon" style="{{ $orderData->count() ? 'color: #ee2400;' : '' }}"></i>
        </button>
        <div class="tooltip">Order List</div>

        <form class="contact-form" id="contactForm" action="{{ route('staff.save-report') }}" method="POST" style="display: none;">
    @csrf

    @if ($orderData->count())
        <label for="orderTextarea" style="display: block; margin-bottom: 8px; font-weight: bold; color: white;">Pending Orders</label>
        <textarea id="orderTextarea" readonly wrap="on"
            style="width: 100%; height: 250px; padding: 10px; font-family: monospace; background-color: #f8f9fa; border: 1px solid #ccc; border-radius: 5px;">
@foreach ($orderData as $item)
Product: {{ $item['name'] }}
Quantity: {{ $item['quantity'] }}
Price: {{ $item['selling_price'] }}
-----------------------
@endforeach
        </textarea>
        
        <p style="color: white; margin-top: 10px;"><strong>Total Price:</strong> {{ $totalOrderPrice }}</p>
        <a href="{{ route('staff.clear-report') }}" id="clearBtn" style="margin-top: 10px;">Clear Record</a>
        <button type="button" id="openPaymentModalBtn" style="margin-top: 10px;">Save Record</button>
        <div class="success-message" id="successMessage" style="display: none; color: green; margin-top: 10px;">Orders Records Saved!</div>
    @else
        <p style="color: white;">No pending orders.</p>
    @endif
</form>
    </div>

<script>
    document.querySelector('.expand-btn').addEventListener('click', function() {
        const form = document.querySelector('.contact-form');
        const tooltip = document.querySelector('.tooltip');
        form.style.display = form.style.display === 'flex' ? 'none' : 'flex';
        tooltip.style.display = form.style.display === 'flex' ? 'none' : 'unset';
    });
</script>

@if ($orderData->count())
@include('includes.paymentstatus')
<script>
document.getElementById('openPaymentModalBtn').addEventListener('click', function () {
    const modal = new bootstrap.Modal(document.getElementById('paymentModal'));
    modal.show();
});

document.getElementById('submitPaymentForm').addEventListener('click', function () {
    const saveReportUrl = "{{ route('staff.save-report') }}";
    const paymentMethodSelect = document.getElementById('modalPaymentMethod');
    const selected = paymentMethodSelect.value;

    if (!selected) {
        alert('Please select a payment method.');
        return;
    }

    const cashInput = document.getElementById('cashAmount');
    const gcashInput = document.getElementById('gcashAmount');
    const paymentModal = document.getElementById('paymentModal'); 
    const rawPrice = paymentModal.dataset.totalPrice.replace(/[^0-9.]/g, ''); 
    const totalOrderPrice = parseFloat(rawPrice);

    if (selected === '3') {
        const cashValue = parseFloat(cashInput.value);
        const gcashValue = parseFloat(gcashInput.value);

        if (!cashInput.value || !gcashInput.value) {
            alert('Please fill both Cash and GCash amounts.');
            return;
        }

    if (cashValue < 1) {
        alert('Cash amount must be at least 1 Peso.');
        return;
    }

    if (gcashValue < 1) {
        alert('GCash amount must be at least 1 Peso.');
        return;
    }

        if (cashValue + gcashValue !== totalOrderPrice) {
            alert(`The sum of Cash and GCash must equal the total price (₱${totalOrderPrice}).`);
            return;
        }
    }

    const contactForm = document.getElementById('contactForm');

    let hiddenInput = contactForm.querySelector('input[name="payment_method"]');
    if (!hiddenInput) {
        hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'payment_method';
        contactForm.appendChild(hiddenInput);
    }
    hiddenInput.value = selected;

    if (selected === '3') {
        contactForm.querySelector('input[name="cashAmount"]')?.remove();
        contactForm.querySelector('input[name="gcashAmount"]')?.remove();

        const cashHidden = document.createElement('input');
        cashHidden.type = 'hidden';
        cashHidden.name = 'cashAmount';
        cashHidden.value = cashInput.value;
        contactForm.appendChild(cashHidden);

        const gcashHidden = document.createElement('input');
        gcashHidden.type = 'hidden';
        gcashHidden.name = 'gcashAmount';
        gcashHidden.value = gcashInput.value;
        contactForm.appendChild(gcashHidden);
    }

    const formData = new FormData(contactForm);


    fetch(saveReportUrl, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(async response => {
        const data = await response.json();
        if (!response.ok) {
            alert(data.error || 'An error occurred.');
            throw new Error(data.error || 'Server error');
        }
        return data;
    })
    .then(data => {
        if (data.success) {
            const formElements = contactForm.querySelectorAll('textarea, button, a, label');
            formElements.forEach(element => element.classList.add('fade-out'));

            setTimeout(() => {
                contactForm.reset();
                formElements.forEach(el => el.classList.add('fade-out-hidden'));
                document.getElementById('successMessage').style.display = 'block';
            }, 500);

            const modalInstance = bootstrap.Modal.getInstance(document.getElementById('paymentModal'));
            modalInstance.hide();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (!error.message) alert('Something went wrong. Please try again.');
    });

});
</script>
@endif


<script>
    const advancedSearchInput = document.getElementById('advanced-search-input');
    const advancedSearchButton = document.getElementById('advanced-search-button');
    const brandItems = document.querySelectorAll('.listBrand .item');

    function filterBrands() {
        const query = advancedSearchInput.value.toLowerCase();

        brandItems.forEach(item => {
            const brandName = item.querySelector('h2').textContent.toLowerCase();
            item.style.display = brandName.includes(query) ? 'block' : 'none';
        });
    }

    advancedSearchInput.addEventListener('input', filterBrands);
    advancedSearchButton.addEventListener('click', filterBrands);
</script>

@endsection
