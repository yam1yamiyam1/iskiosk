<div class="page-body">
    <div class="container-xl">
        <form method="GET" action="{{ route('daily-report.index') }}" class="mb-4" style="max-width: unset;">
            <div class="row g-2">
                <div class="col-md-4">
                    <select name="view_type" class="form-select" onchange="this.form.submit()">
                        <option value="sale" {{ $viewType == 'sale' ? 'selected' : '' }}>View by Sale</option>
                        <option value="product" {{ $viewType == 'product' ? 'selected' : '' }}>View by Product</option>
                    </select>
                </div>
            </div>
        </form>

        <div class="row row-deck row-cards">
            <div class="col-12">
                <div class="input-group mb-4">
                    <input type="text" class="form-control" id="advanced-search-input" placeholder="Search..." />
                    <button class="btn btn-primary" style="background-color: #720100; id="advanced-search-button" type="button">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
            </div>

            @php
                $prevSaleId = null;
                $currentTotal = 0;
                $totalAllSales = 0;
                $totalCash = 0;
                $totalGcash = 0;
                $nextSaleId = null;
            @endphp
            
            <div class="col-12 table-responsive">
                @if (count($saleData) === 0)
                    <div class="alert alert-warning" role="alert">
                        No sales available.
                    </div>
                @else
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Quantity</th>
                            <th>Brand</th>
                            <th>Selling Price</th>
                            <th>Sub Total Price</th>
                            <th>Payment Method</th>
                            <th>Date Created</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($saleData as $index => $sale)
                            @php
                                $isSameSale = $sale['sale_id'] === $prevSaleId;
                                $currentTotal += floatval(str_replace(['₱', ','], '', $sale['total_price']));
                                $totalAllSales += floatval(str_replace(['₱', ','], '', $sale['total_price']));
                                $nextSaleId = $saleData[$index + 1]['sale_id'] ?? null;
                                
                                if ($sale['payment_method'] == 'Cash') {
                                    $totalCash += floatval(str_replace(['₱', ','], '', $sale['total_price']));
                                } elseif ($sale['payment_method'] == 'Gcash') {
                                    $totalGcash += floatval(str_replace(['₱', ','], '', $sale['total_price']));
                                } elseif ($sale['payment_method'] == 'Cash and Gcash') {
                                    if ($sale['sale_id'] !== $nextSaleId) {
                                        $totalCash += $sale['cash'];
                                        $totalGcash += $sale['gcash'];
                                    }
                                }
            
                            @endphp
            
                            <tr class="data-row" style="@if($isSameSale) border-top-style: hidden; @endif ">
                                <td>{{ $sale['sale_id'] }}</td>
                                <td>
                                    @if ($sale['product_image'])
                                        <img src="{{ asset('storage/products/' . $sale['product_image']) }}" alt="Image" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                                    @else
                                        <span class="text-muted">No Image</span>
                                    @endif
                                </td>
                                <td>{{ $sale['product_name'] }}</td>
                                <td>{{ $sale['quantity'] ?? 0 }}</td>
                                <td>{{ $sale['brand_name'] }}</td>
                                <td>{{ $sale['selling_price'] }}</td>
                                <td>{{ $sale['total_price'] }}</td>
                                <td>{{ $sale['payment_method'] }}</td>
                                <td>{{ $sale['created_at'] }}</td>
                                <td>
                                    <a href="#" class="text-primary me-2" data-bs-toggle="modal" data-bs-target="#editSaleModal{{ $sale['order_id'] }}">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="#" class="text-danger" data-bs-toggle="modal" data-bs-target="#deleteSaleModal{{ $sale['order_id'] }}">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
            
                            @if ($sale['sale_id'] !== $nextSaleId)
                                <tr style="background-color: azure;">
                                    <td colspan="8" class="text-end fw-bold">Total for Sale ID {{ $sale['sale_id'] }}:</td>
                                    <td class="fw-bold">
                                        @if ($sale['payment_method'] == 'Cash and Gcash')
                                            <div style="font-weight: normal; font-size: 0.9em;">
                                                @if ($sale['cash'] > 0)
                                                    <div><strong>Cash:</strong> ₱{{ number_format($sale['cash'], 2) }}</div>
                                                @endif
                                                @if ($sale['gcash'] > 0)
                                                    <div><strong>GCash:</strong> ₱{{ number_format($sale['gcash'], 2) }}</div>
                                                @endif
                                            </div>
                                        @endif
                                        ₱{{ number_format($currentTotal, 2) }}
                                    </td>
                                    <td></td>
                                </tr>
                                @php 
                                    $currentTotal = 0; 
                                @endphp
                            @endif

                            @php $prevSaleId = $sale['sale_id']; @endphp
                        @endforeach
                    </tbody>
                </table>
            
                @endif
            </div>
            
            <div class="alert alert-info text-end">
                <strong>Total for Cash: </strong> ₱{{ number_format($totalCash, 2) ?? '0.00' }} <br>
                <strong>Total for Gcash: </strong> ₱{{ number_format($totalGcash, 2) ?? '0.00' }} <br> <br>
                <strong>Total for All Sales: </strong> ₱{{ number_format($totalAllSales, 2) ?? '0.00' }}
            </div>

        </div>
    </div>
</div>

