<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('products.store') }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            <div class="modal-header">
                <h5 class="modal-title" id="addProductModalLabel">Add New Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input name="name" type="text" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Quantity</label>
                    @foreach ($shops as $shop)
                        <div class="input-group mb-2">
                            <span class="input-group-text">{{ $shop->name }}</span>
                            <input type="number" name="quantities[{{ $shop->id }}]" class="form-control" placeholder="Quantity for {{ $shop->name }}" required>
                        </div>
                    @endforeach
                </div>

                <div class="mb-3">
                    <label class="form-label">Brand</label>
                    <select name="brand_id" class="form-control" required>
                        <option value="" disabled selected>Select a brand</option>
                        @foreach($brands as $brand)
                            <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Selling Price</label>
                    <input name="selling_price" type="number" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Quantity Alert</label>
                    <input name="quantity_alert" type="number" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Product Image</label>
                    <input name="product_image" type="file" class="form-control" accept="image/*">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Product</button>
            </div>
        </form>
    </div>
</div>
