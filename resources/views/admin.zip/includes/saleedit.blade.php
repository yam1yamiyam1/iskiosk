<div class="modal fade" id="editSaleModal{{ $sale['order_id'] }}" tabindex="-1" aria-labelledby="editSaleModalLabel{{ $sale['order_id'] }}" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('daily-report.update', $sale['order_id']) }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header">
                <h5 class="modal-title" id="editSaleModalLabel{{ $sale['order_id'] }}">Edit Purchase - {{ $sale['product_name'] }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label" for="quantityInput{{ $sale['order_id'] }}">Quantity</label>
                    <input id="quantityInput{{ $sale['order_id'] }}" name="quantity" type="number" class="form-control" value="{{ $sale['quantity'] }}" min="1" required>
                </div>
                <div class="mb-3">
                    <label for="modalPaymentMethod{{ $sale['order_id'] }}">Payment Method</label>
                    <select name="paymentmethod" id="modalPaymentMethod{{ $sale['order_id'] }}" class="form-control" required>
                        <option value="1" {{ $sale['payment_method'] == 'Cash' ? 'selected' : ''}}>Cash</option>
                        <option value="2" {{ $sale['payment_method'] == 'Gcash' ? 'selected' : ''}}>Gcash</option>
                        <option value="3" {{ $sale['payment_method'] == 'Cash and Gcash' ? 'selected' : ''}}>Cash and Gcash</option>
                    </select>
                    <div id="cashGcashInputs{{ $sale['order_id'] }}" @if($sale['payment_method'] !== 'Cash and Gcash')style="display:none; margin-top: 15px;"@endif>
                        <label for="cashAmount{{ $sale['order_id'] }}">Cash Amount</label>
                        <input type="number" id="cashAmount{{ $sale['order_id'] }}" name="cashAmount" class="form-control" min="@if($sale['payment_method'] == 'Cash and Gcash') 0 @endif" step="1" max="{{ $sale['totalprice'] - 1 }}" value="{{ $sale['cash'] }}" @if($sale['payment_method'] == 'Cash and Gcash') required @endif>

                        <label for="gcashAmount{{ $sale['order_id'] }}" style="margin-top: 10px;">Gcash Amount</label>
                        <input type="number" id="gcashAmount{{ $sale['order_id'] }}" name="gcashAmount" class="form-control" min="@if($sale['payment_method'] == 'Cash and Gcash') 0 @endif" step="1" max="{{ $sale['totalprice'] - 1 }}" value="{{ $sale['gcash'] }}" @if($sale['payment_method'] == 'Cash and Gcash') required @endif>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Total:</label>
                    <div id="totalDisplay{{ $sale['order_id'] }}" 
                        style="background-color: #f8f9fa; border: 1px solid #ced4da; padding: 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; color: #720100;">
                        ₱{{ number_format($sale['totalprice'], 2) }}
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const quantityInput = document.getElementById('quantityInput{{ $sale['order_id'] }}');
    const cashInput = document.getElementById('cashAmount{{ $sale['order_id'] }}');
    const gcashInput = document.getElementById('gcashAmount{{ $sale['order_id'] }}');
    const paymentMethod = document.getElementById('modalPaymentMethod{{ $sale['order_id'] }}');
    const cashGcashInputs = document.getElementById('cashGcashInputs{{ $sale['order_id'] }}');
    const totalDisplay = document.getElementById('totalDisplay{{ $sale['order_id'] }}');

    const quantityStored = {{ $sale['quantity'] }};
    const sellingPrice = parseFloat("{{ str_replace(['₱', ','], '', $sale['selling_price']) }}");

    let totalOrderPrice = {{ $sale['totalprice'] }};

    function updateAmounts(changedField) {
    let cashValue = Math.max(0, parseFloat(cashInput.value) || 0);
    let gcashValue = Math.max(0, parseFloat(gcashInput.value) || 0);

    if (changedField === 'cash') {
        if (cashValue > totalOrderPrice) cashValue = totalOrderPrice;
        gcashValue = totalOrderPrice - cashValue;
    } else if (changedField === 'gcash') {
        if (gcashValue > totalOrderPrice) gcashValue = totalOrderPrice;
        cashValue = totalOrderPrice - gcashValue;
    }
    cashInput.value = cashValue;
    gcashInput.value = gcashValue;
    totalDisplay.textContent = `₱${(cashValue + gcashValue).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}


    function updateTotal() {
        const currentQuantity = parseInt(quantityInput.value) || 0;
        const quantityDiff = currentQuantity - quantityStored;
        totalOrderPrice = {{ $sale['totalprice'] }} + quantityDiff * sellingPrice;

        cashInput.max = totalOrderPrice - 1;
        gcashInput.max = totalOrderPrice - 1;
        if (paymentMethod.value === '3') {
            cashInput.value = 0;
            gcashInput.value = 0;
            updateAmounts('cash');
        } else {
            totalDisplay.textContent = `₱${totalOrderPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        }
    }

    quantityInput.addEventListener('input', updateTotal);
    cashInput.addEventListener('input', () => updateAmounts('cash'));
    gcashInput.addEventListener('input', () => updateAmounts('gcash'));

    paymentMethod.addEventListener('change', () => {
        if (paymentMethod.value === '3') {
            cashGcashInputs.style.display = 'block';
            cashInput.max = totalOrderPrice - 1;
            gcashInput.max = totalOrderPrice - 1;
            cashInput.min = 1;
            gcashInput.min = 1;
            cashInput.value = 0;
            gcashInput.value = 0;
            cashInput.required = true;
            gcashInput.required = true;
            updateAmounts('cash');
        } else {
            cashGcashInputs.style.display = 'none';
            cashInput.required = false;
            gcashInput.required = false;
            totalDisplay.textContent = `₱${totalOrderPrice.toFixed(2)}`;
        }
    });
});
</script>
