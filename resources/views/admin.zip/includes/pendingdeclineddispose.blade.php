<div class="modal fade" id="declinedisposeModal" tabindex="-1" aria-labelledby="declinedisposeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="{{ route('sales.declinedisposal') }}">
                @csrf
                <input type="hidden" name="shop_id" value="{{ $selectedShop }}">
                <div class="modal-header">
                    <h5 class="modal-title" id="declinedisposeModalLabel">Confirm Decline</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to decline all pending disposes for this shop? This will restore the stock.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Yes, Decline All</button>
                </div>
            </form>
        </div>
    </div>
</div>