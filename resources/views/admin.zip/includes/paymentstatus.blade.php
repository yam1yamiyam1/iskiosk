<div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true" data-total-price="{{ $totalOrderPrice }}">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="paymentModalLabel">Select Payment Method</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <label for="modalPaymentMethod">Payment Method</label>
        <select id="modalPaymentMethod" class="form-control" required>
          <option value="">Select Payment Method</option>
          <option value="1">Cash</option>
          <option value="2">Gcash</option>
          <option value="3">Cash and Gcash</option>
        </select>

        <div id="cashGcashInputs" style="display:none; margin-top: 15px;">
          <label for="cashAmount">Cash Amount</label>
          <input type="number" id="cashAmount" name="cashAmount" class="form-control" min="1" step="1">

          <label for="gcashAmount" style="margin-top: 10px;">Gcash Amount</label>
          <input type="number" id="gcashAmount" name="gcashAmount" class="form-control" min="1" step="1">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" id="submitPaymentForm" class="btn btn-primary">Confirm and Save</button>
      </div>
    </div>
  </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', () => {
  const paymentModal = document.getElementById('paymentModal'); 
  const rawPrice = paymentModal.dataset.totalPrice.replace(/[^0-9.]/g, ''); 
  const totalOrderPrice = parseFloat(rawPrice);

  const paymentMethod = document.getElementById('modalPaymentMethod');
  const cashInput = document.getElementById('cashAmount');
  const gcashInput = document.getElementById('gcashAmount');
  const cashGcashInputs = document.getElementById('cashGcashInputs');

  paymentMethod.addEventListener('change', () => {
    if (paymentMethod.value === '3') {
      cashGcashInputs.style.display = 'block';
      cashInput.max = totalOrderPrice;
      gcashInput.max = totalOrderPrice;
      cashInput.min = 1;
      gcashInput.min = 1;
      cashInput.value = '';
      gcashInput.value = '';
      cashInput.required = true;
      gcashInput.required = true;
    } else {
      cashGcashInputs.style.display = 'none';
      cashInput.required = false;
      gcashInput.required = false;
    }
  });

  function updateAmounts(changedField) {
    let cashValue = parseFloat(cashInput.value) || 0;
    let gcashValue = parseFloat(gcashInput.value) || 0;

    if (changedField === 'cash') {
      if (cashValue > totalOrderPrice) cashValue = totalOrderPrice;
      if (cashValue < 1 && cashInput.value !== '') cashValue = 1;
      gcashValue = totalOrderPrice - cashValue;
      if (gcashValue < 0) gcashValue = 0;
    }

    if (changedField === 'gcash') {
      if (gcashValue > totalOrderPrice) gcashValue = totalOrderPrice;
      if (gcashValue < 1 && gcashInput.value !== '') gcashValue = 1;
      cashValue = totalOrderPrice - gcashValue;
      if (cashValue < 0) cashValue = 0;
    }

    cashInput.value = cashValue;
    gcashInput.value = gcashValue;
  }

  cashInput.addEventListener('input', () => updateAmounts('cash'));
  gcashInput.addEventListener('input', () => updateAmounts('gcash'));
});
</script>
