<div class="modal fade" id="editBrandModal{{ $brand['id'] }}" tabindex="-1" aria-labelledby="editBrandModalLabel{{ $brand['id'] }}" aria-hidden="true">
    <div class="modal-dialog">
    <form method="POST" action="{{ route('brands.update', $brand['id']) }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header">
                <h5 class="modal-title" id="editBrandModalLabel{{ $brand['id'] }}">Edit Brand</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input name="name" type="text" class="form-control" value="{{ $brand['name'] }}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cover Image</label>
                    <input name="brand_image" type="file" class="form-control" accept="image/*">
                    @if ($brand['brand_image'])
                        <div class="mt-2">
                            <img src="{{ asset('storage/brands/' . $brand['brand_image']) }}" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                        </div>
                    @endif
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Brand</button>
            </div>
        </form>
    </div>
</div>
