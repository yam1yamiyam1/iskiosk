<div class="modal fade" id="editProductModal{{ $product['id'] }}" tabindex="-1" aria-labelledby="editProductModalLabel{{ $product['id'] }}" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('products.update', $product['id']) }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel{{ $product['id'] }}">Edit Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input name="name" type="text" class="form-control" value="{{ $product['name'] }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Quantity</label>
                    @if ($selectedShop === 'all')
                        @foreach ($shops as $shop)
                            <div class="input-group mb-2">
                                <span class="input-group-text">{{ $shop->name }}</span>
                                <input type="number" name="quantities[{{ $shop->id }}]" class="form-control" value="{{ $product['quantities'][$shop->id] ?? 0 }}" placeholder="Quantity for {{ $shop->name }}" required>
                            </div>
                        @endforeach
                    @else
                        <input type="number" name="quantities[{{ $selectedShop }}]" class="form-control" value="{{ $product['quantities'][$selectedShop] ?? 0 }}" placeholder="Quantity for selected shop" required>
                    @endif
                </div>

                <div class="mb-3">
                    <label class="form-label">Brand</label>
                    <select name="brand_id" class="form-control" required>
                        @foreach($brands as $brand)
                            <option value="{{ $brand->id }}" {{ $product['brand_id'] == $brand->id ? 'selected' : '' }}>{{ $brand->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Selling Price</label>
                    <input name="selling_price" type="number" class="form-control" value="{{ preg_replace('/[^0-9.]/', '', $product['selling_price']) }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Quantity Alert</label>
                    <input name="quantity_alert" type="number" class="form-control" value="{{ $product['quantity_alert'] }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Product Image</label>
                    <input name="product_image" type="file" class="form-control" accept="image/*">
                    @if ($product['product_image'])
                        <div class="mt-2">
                            <img src="{{ asset('storage/products/' . $product['product_image']) }}" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                        </div>
                    @endif
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Update Product</button>
            </div>
        </form>
    </div>
</div>
