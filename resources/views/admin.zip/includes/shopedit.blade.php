<div class="modal fade" id="editShopModal{{ $shop['id'] }}" tabindex="-1" aria-labelledby="editShopModalLabel{{ $shop['id'] }}" aria-hidden="true">
    <div class="modal-dialog">
    <form method="POST" action="{{ route('shops.update', $shop['id']) }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header">
                <h5 class="modal-title" id="editShopModalLabel{{ $shop['id'] }}">Edit Shop</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input name="name" type="text" class="form-control" value="{{ $shop['name'] }}" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Save Shop</button>
            </div>
        </form>
    </div>
</div>
