<div class="modal fade" id="editUserModal{{ $user['id'] }}" tabindex="-1" aria-labelledby="editUserModalLabel{{ $user['id'] }}" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('users.update', $user['id']) }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            @method('PUT')
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel{{ $user['id'] }}">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">First Name</label>
                    <input name="fname" type="text" class="form-control" value="{{ $user['fname'] }}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Middle Initial</label>
                    <input name="mi" type="text" class="form-control" value="{{ $user['mi'] }}" maxlength="2">
                </div>
                <div class="mb-3">
                    <label class="form-label">Last Name</label>
                    <input name="lname" type="text" class="form-control" value="{{ $user['lname'] }}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input name="email" type="email" class="form-control" value="{{ $user['email'] }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-control" required onchange="toggleShopDropdown({{ $user['id'] }})">
                        <option value="1" {{ $user->hasRole(1) ? 'selected' : '' }}>Admin</option>
                        <option value="0" {{ $user->hasRole(0) ? 'selected' : '' }}>Staff</option>
                    </select>
                </div>

                <div class="mb-3" id="shopDropdown{{ $user['id'] }}" style="display: none;">
                    <label class="form-label">Shop</label>
                    <select name="shop" class="form-control">
                        @foreach ($shops as $shop)
                            <option value="{{ $shop->id }}" {{ $user->shop_id == $shop->id ? 'selected' : '' }}>{{ $shop->name }}</option>
                        @endforeach
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="1" {{ $user['status'] == 1 ? 'selected' : '' }}>Active</option>
                        <option value="0" {{ $user['status'] == 0 ? 'selected' : '' }}>Inactive</option>
                    </select>
                </div>
                <div class="mb-3 position-relative">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <input id="editPassword{{ $user['id'] }}" name="password" type="password" class="form-control" placeholder="Leave blank to keep current password">
                        <button class="btn btn-outline-primary" type="button" onclick="generatePassword('editPassword{{ $user['id'] }}', 'editConfirmPassword{{ $user['id'] }}')">Generate</button>
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('editPassword{{ $user['id'] }}')">
                            <i class="bi bi-eye-slash" id="eyeEditPassword{{ $user['id'] }}"></i>
                        </button>
                    </div>
                </div>

                <div class="mb-3 position-relative">
                    <label class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <input id="editConfirmPassword{{ $user['id'] }}" name="password_confirmation" type="password" class="form-control" placeholder="Leave blank to keep current password">
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePassword('editConfirmPassword{{ $user['id'] }}')">
                            <i class="bi bi-eye-slash" id="eyeEditConfirmPassword{{ $user['id'] }}"></i>
                        </button>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Profile Image</label>
                    <input name="image" type="file" class="form-control" accept="image/*">
                    @if ($user['image'])
                        <div class="mt-2">
                            <img src="{{ asset('storage/users/' . $user['image']) }}" width="60" height="60" style="object-fit: cover; border-radius: 4px;">
                        </div>
                    @endif
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Update User</button>
            </div>
        </form>
    </div>
</div>
<script>
function toggleShopDropdown(userId) {
    const roleSelect = document.querySelector(`#editUserModal${userId} select[name="role"]`);
    const shopDropdown = document.querySelector(`#shopDropdown${userId}`);

    if (roleSelect.value == 0) {
        shopDropdown.style.display = 'block';
    } else {
        shopDropdown.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', function() {
    @foreach ($users as $user)
        toggleShopDropdown({{ $user['id'] }});
    @endforeach
});

function togglePassword(id) {
    const input = document.getElementById(id);
    const icon = document.getElementById('eye' + id.charAt(0).toUpperCase() + id.slice(1));
    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");
    } else {
        input.type = "password";
        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");
    }
}

function generatePassword(passwordId, confirmPasswordId = null) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    let password = "";
    for (let i = 0; i < 12; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    const passInput = document.getElementById(passwordId);
    const confirmInput = document.getElementById(confirmPasswordId);
    const passIcon = document.getElementById('eye' + passwordId.charAt(0).toUpperCase() + passwordId.slice(1));
    const confirmIcon = document.getElementById('eye' + confirmPasswordId.charAt(0).toUpperCase() + confirmPasswordId.slice(1));

    passInput.value = password;
    passInput.type = 'text';
    if (passIcon) {
        passIcon.classList.remove("bi-eye-slash");
        passIcon.classList.add("bi-eye");
    }

    if (confirmInput) {
        confirmInput.value = password;
        confirmInput.type = 'text';
        if (confirmIcon) {
            confirmIcon.classList.remove("bi-eye-slash");
            confirmIcon.classList.add("bi-eye");
        }
    }
}
</script>


