<div class="modal fade" id="restockProductsModal" tabindex="-1" aria-labelledby="restockProductsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('products.restock') }}" enctype="multipart/form-data" class="modal-content">
            @csrf
            <div class="modal-header">
                <h5 class="modal-title" id="restockProductsModalLabel">Restock Products</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Upload Products File</label>
                    <input name="file" type="file" class="form-control" required accept=".xlsx,.xls,.csv">
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Restock Products</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </form>
    </div>
</div>
