<div class="modal fade" id="addQuantityModal" tabindex="-1" aria-labelledby="addQuantityModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('home.store') }}" id="purchaseForm">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="addQuantityModalLabel">Add Purchase</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="product_id" id="modalProductId">
                    <div class="mb-3">
                        <label class="form-label">Quantity</label>
                        <input name="quantity" id="modalQuantity" type="number" class="form-control" value="1" min="1" step="1" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save Records</button>
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#confirmDisposeModal">Dispose</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmDisposeModal" tabindex="-1" aria-labelledby="confirmDisposeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="POST" action="{{ route('home.dispose') }}">
            @csrf
            <input type="hidden" name="product_id_dispose" id="disposeProductId">
            <div class="modal-content rounded-3 shadow">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold text-danger" id="confirmDisposeModalLabel">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> Confirm Disposal
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p class="mb-3 fs-5">Are you sure you want to dispose of this product?</p>
                </div>
                <div class="modal-footer border-0 d-flex justify-content-center gap-2">
                    <button type="submit" class="btn btn-danger px-4">
                        <i class="bi bi-trash3-fill me-1"></i> Yes, Dispose
                    </button>
                    <button type="button" class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">
                        Cancel
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
