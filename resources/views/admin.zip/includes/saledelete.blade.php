<div class="modal fade" id="deleteSaleModal{{ $sale['order_id'] }}" tabindex="-1" aria-labelledby="deleteSaleModalLabel{{ $sale['order_id'] }}" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="{{ route('daily-report.destroy', $sale['order_id']) }}" class="modal-content">
            @csrf
            @method('DELETE')
            <div class="modal-header">
                <h5 class="modal-title" id="deleteSaleModalLabel{{ $sale['order_id'] }}">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                Are you sure you want to delete <strong>{{ $sale['product_name'] }}</strong> in Customer ID <strong>#{{ $sale['sale_id'] }}</strong>?
                </div>

                <div class="mb-3" @if($sale['payment_method'] !== 'Cash and Gcash' || ($sale['totalprice'] - $sale['subtotalprice']) < 1)style="display:none; margin-top: 15px;"@endif>
                    <label for="modalPaymentMethoddelete{{ $sale['order_id'] }}">Payment Method</label>
                    <select name="paymentmethoddelete" id="modalPaymentMethoddelete{{ $sale['order_id'] }}" class="form-control" @if($sale['payment_method'] == 'Cash and Gcash' && $sale['totalprice'] != $sale['subtotalprice']) required @endif>
                        <option value="1" {{ $sale['payment_method'] == 'Cash' ? 'selected' : ''}}>Cash</option>
                        <option value="2" {{ $sale['payment_method'] == 'Gcash' ? 'selected' : ''}}>Gcash</option>
                        <option value="3" {{ $sale['payment_method'] == 'Cash and Gcash' ? 'selected' : ''}}>Cash and Gcash</option>
                    </select>
                    <div id="cashGcashInputsdelete{{ $sale['order_id'] }}">
                        <label for="cashAmountdelete{{ $sale['order_id'] }}">Cash Amount</label>
                        <input type="number" id="cashAmountdelete{{ $sale['order_id'] }}" name="cashAmountdelete" class="form-control" min="1" step="1" max="{{ ($sale['totalprice'] - 1) - $sale['subtotalprice'] }}" value="" @if($sale['payment_method'] == 'Cash and Gcash' && $sale['totalprice'] != $sale['subtotalprice']) required @endif>

                        <label for="gcashAmountdelete{{ $sale['order_id'] }}" style="margin-top: 10px;">Gcash Amount</label>
                        <input type="number" id="gcashAmountdelete{{ $sale['order_id'] }}" name="gcashAmountdelete" class="form-control" min="1" step="1" max="{{ ($sale['totalprice'] - 1) - $sale['subtotalprice'] }}" value="" @if($sale['payment_method'] == 'Cash and Gcash' && $sale['totalprice'] != $sale['subtotalprice']) required @endif>
                    </div>
                </div>
                <div class="mb-3" @if($sale['payment_method'] !== 'Cash and Gcash' || ($sale['totalprice'] - $sale['subtotalprice']) < 1)style="display:none;"@endif>
                    <label class="form-label">Total:</label>
                    <div id="totalDisplaydelete{{ $sale['order_id'] }}" 
                        style="background-color: #f8f9fa; border: 1px solid #ced4da; padding: 10px; border-radius: 5px; font-weight: bold; font-size: 1.1rem; color: #720100;">
                        ₱{{ number_format($sale['totalprice'] - $sale['subtotalprice'], 2) }}
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const cashInput = document.getElementById('cashAmountdelete{{ $sale['order_id'] }}');
        const gcashInput = document.getElementById('gcashAmountdelete{{ $sale['order_id'] }}');
        const paymentMethod = document.getElementById('modalPaymentMethoddelete{{ $sale['order_id'] }}');
        const cashGcashInputsdelete = document.getElementById('cashGcashInputsdelete{{ $sale['order_id'] }}');
        const totalDisplaydelete = document.getElementById('totalDisplaydelete{{ $sale['order_id'] }}');

        const quantityStored = {{ $sale['quantity'] }};
        const sellingPrice = parseFloat("{{ str_replace(['₱', ','], '', $sale['selling_price']) }}");

        let totalOrderPrice = {{ $sale['totalprice'] }} - {{ $sale['subtotalprice']}};

        function updateAmounts(changedField) {
        let cashValue = Math.max(0, parseFloat(cashInput.value) || 0);
        let gcashValue = Math.max(0, parseFloat(gcashInput.value) || 0);

        if (changedField === 'cash') {
            if (cashValue > totalOrderPrice) cashValue = totalOrderPrice;
            gcashValue = totalOrderPrice - cashValue;
        } else if (changedField === 'gcash') {
            if (gcashValue > totalOrderPrice) gcashValue = totalOrderPrice;
            cashValue = totalOrderPrice - gcashValue;
        }
        
        cashInput.value = cashValue;
        gcashInput.value = gcashValue;
        totalDisplaydelete.textContent = `₱${(cashValue + gcashValue).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

        cashInput.addEventListener('input', () => updateAmounts('cash'));
        gcashInput.addEventListener('input', () => updateAmounts('gcash'));

        paymentMethod.addEventListener('change', () => {
            if (paymentMethod.value === '3') {
                cashGcashInputsdelete.style.display = 'block';
                cashInput.max = totalOrderPrice - 1;
                gcashInput.max = totalOrderPrice - 1;
                cashInput.min = 1;
                gcashInput.min = 1;
                cashInput.value = 0;
                gcashInput.value = 0;
                cashInput.required = true;
                gcashInput.required = true;
                updateAmounts('cash');
            } else {
                cashGcashInputsdelete.style.display = 'none';
                cashInput.required = false;
                gcashInput.required = false;
                totalDisplaydelete.textContent = `₱${totalOrderPrice.toFixed(2)}`;
            }
        });
    });
</script>